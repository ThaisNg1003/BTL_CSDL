# Assets / Images

Đặt ảnh tĩnh phục vụ giao diện vào thư mục này để tránh phải dùng link ngoài.

Các file `.svg` mẫu được thêm sẵn (profile, QR, package, HLV). Bạn có thể:

1. Thay thế nội dung SVG bằng ảnh PNG/JPG của bạn (giữ nguyên tên file để không cần sửa code).
2. Hoặc thêm file mới rồi cập nhật đường dẫn trong `index.html` / `app.js`.

Gợi ý tổ chức:

- `profile-placeholder.svg`: ảnh đại diện khu vực hồ sơ.
- `qr-placeholder.svg`: ảnh QR thanh toán.
- `package-*.svg`: thumbnail cho từng gói tập.
- `hlv-*.svg`: ảnh cho huấn luyện viên.

Thư mục này không có build step đặc biệt; chỉ cần chép ảnh vào là frontend sẽ truy cập được qua đường dẫn tương đối `assets/images/<file>`.

