# Hướng dẫn kết nối Database

## Bước 1: Tạo file .env

Tạo file `server/.env` với nội dung sau:

```env
# Database Configuration
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=Thai1003@
DB_NAME=gym_management

# Server Configuration
PORT=3000
```

**Lưu ý:** Thay đổi `DB_PASSWORD` thành password MySQL của bạn.

## Bước 2: Import Database

### Cách 1: Sử dụng script tự động (Khuyến nghị)

**Windows (PowerShell):**
```powershell
.\setup_database.ps1
```

**Windows (CMD):**
```cmd
setup_database.bat
```

**Hoặc chạy trực tiếp:**
```bash
cd server
npm run import-db
```

### Cách 2: Import thủ công bằng MySQL Workbench

1. Mở MySQL Workbench
2. Kết nối với MySQL server
3. Tạo database mới tên `gym_management`:
   ```sql
   CREATE DATABASE gym_management CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```
4. Chọn database `gym_management`
5. File → Run SQL Script
6. Chọn file `gym_management.sql`
7. Nhấn Execute

### Cách 3: Import bằng Command Line

```bash
mysql -u root -p < gym_management.sql
```

Hoặc nếu MySQL không có trong PATH:
```bash
"C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe" -u root -p < gym_management.sql
```

## Bước 3: Kiểm tra kết nối

Sau khi import xong, chạy server:

```bash
cd server
npm start
```

Nếu kết nối thành công, bạn sẽ thấy:
```
✅ API & static server đang chạy tại http://localhost:3000
```

## Cấu trúc Database

Database `gym_management` bao gồm các bảng:

- `tai_khoan` - Tài khoản người dùng
- `Goi_tap` - Gói tập
- `HLV` - Huấn luyện viên
- `Khach_hang` - Thông tin khách hàng/hội viên
- `Thanh_toan` - Lịch sử thanh toán
- `Dat_lich` - Lịch đặt tập với PT
- `system_settings` - Cài đặt hệ thống

## Xử lý lỗi

### Lỗi: ECONNREFUSED
- **Nguyên nhân:** MySQL service chưa chạy
- **Giải pháp:** Khởi động MySQL service

### Lỗi: ER_ACCESS_DENIED_ERROR
- **Nguyên nhân:** Sai username hoặc password
- **Giải pháp:** Kiểm tra lại thông tin trong file `server/.env`

### Lỗi: ER_BAD_DB_ERROR
- **Nguyên nhân:** Database chưa được tạo
- **Giải pháp:** Script sẽ tự động tạo database khi import

## Thông tin mặc định

- **Database:** gym_management
- **Username:** root (mặc định)
- **Password:** Thai1003@ (cần thay đổi)
- **Host:** localhost
- **Port:** 3306

