// app.js
// Frontend logic: đăng ký, đăng nhập, hiển thị gói, booking flow, profile edit.
// Thực hiện fetch tới các endpoint /api/... nếu có backend, nếu không sẽ fallback vào localStorage.

const API = {
  register: '/api/register',
  login: '/api/login',
  adminLogin: '/api/admin-login',
  hlvLogin: '/api/hlv-login',
  packages: '/api/packages',
  book: '/api/book',
  profile: '/api/profile',
  payments: '/api/payments',
  settings: '/api/settings'
};

// --- App state ---
let state = {
  currentUser: null, // {account_id, username, ten, ...}
  selectedPackage: null,
  selectedLich: null,
  selectedHlv: null,
  packageMeta: null,
  packages: [],
  hlvList: [],
  selectedDate: null,
  selectedTimeSlot: null,
  selectedScheduleLabel: null,
  settings: null // System settings from database
};

const DEFAULT_TIME_SLOTS = [
  '06:00 - 08:00',
  '08:00 - 10:00',
  '10:00 - 12:00',
  '12:00 - 14:00',
  '14:00 - 16:00',
  '16:00 - 18:00',
  '18:00 - 20:00',
  '20:00 - 22:00'
];

// --- Init ---
document.addEventListener('DOMContentLoaded', async () => {
  await loadSettings();
  bindUI();
  initPackageCustomizer();
  enableModalUX();
  initSchedulePicker();
  await loadPackages();
  renderUserState();
});

function showToast({ title = '', message = '', type = 'info', timeout = 3000 } = {}){
  const container = document.getElementById('toast-container');
  if(!container) return alert(message || title || 'Thông báo');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <div class="toast-header">${title || 'Thông báo'}</div>
    <p class="toast-message">${message || ''}</p>
    <button type="button" aria-label="Đóng">&times;</button>
  `;
  container.appendChild(toast);
  const removeToast = ()=> toast.remove();
  toast.querySelector('button').addEventListener('click', removeToast);
  setTimeout(removeToast, timeout);
}

// --- UI bindings ---
function bindUI(){
  const elBtnRegister = document.getElementById('btn-register'); if(elBtnRegister) elBtnRegister.addEventListener('click', ()=> showModal('register'));
  const elBtnLogin = document.getElementById('btn-login'); if(elBtnLogin) elBtnLogin.addEventListener('click', ()=> showModal('login'));
  const elAdminLink = document.getElementById('link-admin'); 
  if(elAdminLink){
    elAdminLink.addEventListener('click', (e)=>{
      e.preventDefault();
      showModal('admin');
    });
  }
  const elBtnHlvLogin = document.getElementById('btn-hlv-login-open'); if(elBtnHlvLogin) elBtnHlvLogin.addEventListener('click', ()=> showModal('hlv'));
  const elCloseLogin = document.getElementById('close-login'); if(elCloseLogin) elCloseLogin.addEventListener('click', (e)=> { e.preventDefault(); hideModal('login'); });
  const elCloseRegister = document.getElementById('close-register'); if(elCloseRegister) elCloseRegister.addEventListener('click', (e)=> { e.preventDefault(); hideModal('register'); });
  const elCloseAdminLogin = document.getElementById('close-admin-login'); if(elCloseAdminLogin) elCloseAdminLogin.addEventListener('click', (e)=> { e.preventDefault(); hideModal('admin'); });
  const elCloseHlvLogin = document.getElementById('close-hlv-login'); if(elCloseHlvLogin) elCloseHlvLogin.addEventListener('click', (e)=> { e.preventDefault(); hideModal('hlv'); });
  const chipToggle = document.getElementById('user-chip-toggle');
  const userMenu = document.getElementById('user-menu');
  if(chipToggle && userMenu){
    chipToggle.addEventListener('click', (e)=>{
      e.stopPropagation();
      userMenu.classList.toggle('hidden');
    });
    userMenu.addEventListener('click', (e)=> e.stopPropagation());
    document.addEventListener('click', ()=>{
      if(!userMenu.classList.contains('hidden')){
        userMenu.classList.add('hidden');
      }
    });
  }

  const elFormRegister = document.getElementById('form-register'); if(elFormRegister) elFormRegister.addEventListener('submit', onRegister);
  const elFormLogin = document.getElementById('form-login'); if(elFormLogin) elFormLogin.addEventListener('submit', onLogin);
  const elFormAdminLogin = document.getElementById('form-admin-login'); if(elFormAdminLogin) elFormAdminLogin.addEventListener('submit', onAdminLogin);
  const elFormHlvLogin = document.getElementById('form-hlv-login'); if(elFormHlvLogin) elFormHlvLogin.addEventListener('submit', onHlvLogin);
  const elBtnLogout = document.getElementById('btn-logout'); if(elBtnLogout) elBtnLogout.addEventListener('click', logout);
  const editCardBtn = document.getElementById('btn-edit-profile-card'); if(editCardBtn) editCardBtn.addEventListener('click', ()=> { showSection('profile-edit'); setSidebarActiveById('btn-view-profile'); });

  const elBtnPackages = document.getElementById('btn-packages'); if(elBtnPackages) elBtnPackages.addEventListener('click', ()=> scrollToPackages());

  // profile view buttons
  document.getElementById('btn-view-profile').addEventListener('click', ()=> {
    showSection('profile-edit');
    setSidebarActiveById('btn-view-profile');
    openSidebarWindow('profile');
  });
  document.getElementById('btn-view-schedule').addEventListener('click', ()=> {
    showSection('profile-schedule');
    setSidebarActiveById('btn-view-schedule');
    openSidebarWindow('schedule');
  });
  document.getElementById('btn-view-hlv').addEventListener('click', ()=> {
    showSection('profile-hlv');
    setSidebarActiveById('btn-view-hlv');
    openSidebarWindow('hlv');
  });
  document.getElementById('btn-view-payment').addEventListener('click', ()=> {
    showSection('payment-table');
    setSidebarActiveById('btn-view-payment');
    openSidebarWindow('payment');
  });
  document.getElementById('form-edit-profile').addEventListener('submit', onProfileEdit);

  // booking flow control
  document.getElementById('cancel-booking').addEventListener('click', cancelBooking);
  document.getElementById('to-step-2').addEventListener('click', ()=> {
    if(!state.selectedPackage){ alert('Chọn 1 gói trước!'); return; }
    document.getElementById('step-2').classList.remove('hidden');
  });
  document.getElementById('back-step-1').addEventListener('click', ()=> document.getElementById('step-2').classList.add('hidden'));
  document.getElementById('to-step-3').addEventListener('click', onToStep3);
  document.getElementById('back-step-2').addEventListener('click', ()=> {
    document.getElementById('step-3').classList.add('hidden');
    document.getElementById('step-2').classList.remove('hidden');
  });
  document.getElementById('confirm-pay').addEventListener('click', confirmPayment);

  const sidebarWindow = document.getElementById('sidebar-window');
  const sidebarWindowClose = document.getElementById('sidebar-window-close');
  if(sidebarWindowClose){
    sidebarWindowClose.addEventListener('click', closeSidebarWindow);
  }
  if(sidebarWindow){
    sidebarWindow.addEventListener('click', (e)=>{
      if(e.target === sidebarWindow){
        closeSidebarWindow();
      }
    });
  }
}

function initPackageCustomizer(){
  const form = document.getElementById('package-custom-form');
  if(!form) return;
  const goalSelect = document.getElementById('goal-select');
  const startDateInput = document.getElementById('start-date');
  const sessionInput = document.getElementById('session-input');
  const sessionValue = document.getElementById('session-value');
  const addonInputs = form.querySelectorAll('.addon-list input[type="checkbox"]');
  const planInputs = form.querySelectorAll('input[name="plan"]');
  const coachPreference = document.getElementById('coach-preference');
  const notesInput = document.getElementById('notes');
  const summaryName = document.getElementById('summary-plan-name');
  const summaryMeta = document.getElementById('summary-meta');
  const summaryPrice = document.getElementById('summary-price');

  const highlightPlans = ()=>{
    planInputs.forEach(input=>{
      const wrap = input.closest('.plan-option');
      if(wrap){
        wrap.classList.toggle('active', input.checked);
      }
    });
  };

  const computeSummary = ()=>{
    highlightPlans();
    const planInput = form.querySelector('input[name="plan"]:checked');
    if(!planInput) return;
    const basePrice = Number(planInput.dataset.price) || 0;
    let total = basePrice;
    const addons = [];
    addonInputs.forEach(cb=>{
      if(cb.checked){
        total += Number(cb.dataset.price) || 0;
        addons.push(cb.dataset.label);
      }
    });
    const sessionCount = Number(sessionInput.value);
    sessionValue.textContent = sessionCount;
    const sessionMultiplier = sessionCount > 3 ? 1 + (sessionCount - 3) * 0.05 : 1;
    const finalPrice = Math.round(total * sessionMultiplier);
    const goalText = goalSelect.options[goalSelect.selectedIndex].text;
    const startDateReadable = startDateInput.value ? new Date(startDateInput.value).toLocaleDateString('vi-VN') : 'Chưa chọn';
    const coachText = coachPreference.options[coachPreference.selectedIndex].text;

    summaryName.textContent = planInput.dataset.label;
    summaryMeta.innerHTML = `Mục tiêu: <strong>${goalText}</strong><br/>Bắt đầu: ${startDateReadable}<br/>HLV: ${coachText}<br/>Tiện ích: ${addons.length?addons.join(', '):'Không'}<br/>Buổi/tuần: ${sessionCount}`;
    summaryPrice.textContent = formatMoney(finalPrice);

    form.dataset.price = finalPrice;
    form.dataset.planLabel = planInput.dataset.label || '';
    form.dataset.goalText = goalText;
    form.dataset.goalValue = goalSelect.value;
    form.dataset.startDateText = startDateReadable;
    form.dataset.startDateValue = startDateInput.value;
    form.dataset.sessions = sessionCount;
    form.dataset.addons = JSON.stringify(addons);
    form.dataset.notes = notesInput.value.trim();
    form.dataset.coachPref = coachPreference.value;
    form.dataset.coachText = coachText;
    form.dataset.goiId = planInput.value;
  };

  form.addEventListener('input', (e)=>{
    if(e.target.matches('input, select, textarea')){
      computeSummary();
    }
  });
  form.addEventListener('change', (e)=>{
    if(e.target.matches('input[type="radio"], input[type="checkbox"], select')){
      computeSummary();
    }
  });

  form.addEventListener('submit', (e)=>{
    e.preventDefault();
    if(!form.dataset.startDateValue){
      alert('Vui lòng chọn ngày bắt đầu');
      startDateInput.focus();
      return;
    }
    const addons = form.dataset.addons ? JSON.parse(form.dataset.addons) : [];
    const meta = {
      planLabel: form.dataset.planLabel,
      goal: form.dataset.goalText,
      goalValue: form.dataset.goalValue,
      startDate: form.dataset.startDateValue,
      readableStartDate: form.dataset.startDateText,
      sessions: Number(form.dataset.sessions || 0),
      addons,
      notes: form.dataset.notes || '',
      coachPreference: form.dataset.coachText,
      coachPreferenceValue: form.dataset.coachPref,
      priceOverride: Number(form.dataset.price || 0)
    };
    if(!meta.planLabel){
      computeSummary();
      return;
    }
    startBooking(Number(form.dataset.goiId), meta);
    document.getElementById('booking-flow').scrollIntoView({behavior:'smooth'});
  });

  // set default date today for better UX
  const today = new Date().toISOString().split('T')[0];
  startDateInput.value = today;
  computeSummary();
}

// --- Modal helpers ---
function showModal(which){
  let m = null;
  if(which === 'login') m = document.getElementById('modal-login');
  else if(which === 'register') m = document.getElementById('modal-register');
  else if(which === 'admin') m = document.getElementById('modal-admin-login');
  else if(which === 'hlv') m = document.getElementById('modal-hlv-login');
  if(!m) return;
  m.classList.remove('hidden');
  // also ensure it's visible if inline style was set
  m.style.display = '';
}
function hideModal(which){
  let m = null;
  if(which === 'login') m = document.getElementById('modal-login');
  else if(which === 'register') m = document.getElementById('modal-register');
  else if(which === 'admin') m = document.getElementById('modal-admin-login');
  else if(which === 'hlv') m = document.getElementById('modal-hlv-login');
  if(!m) return;
  m.classList.add('hidden');
  // defensive: also hide via style in case CSS differs
  m.style.display = 'none';
}

// Close modal when clicking outside inner or pressing Escape
function enableModalUX(){
  ['modal-login','modal-register','modal-admin-login','modal-hlv-login'].forEach(id=>{
    const m = document.getElementById(id);
    if(!m) return;
    m.addEventListener('click', (e)=>{
      if(e.target === m){
        m.classList.add('hidden');
        m.style.display = 'none';
      }
    });
  });

  window.addEventListener('keydown', (e)=>{
    if(e.key === 'Escape'){
      const ml = document.getElementById('modal-login'); if(ml && !ml.classList.contains('hidden')) hideModal('login');
      const mr = document.getElementById('modal-register'); if(mr && !mr.classList.contains('hidden')) hideModal('register');
      const ma = document.getElementById('modal-admin-login'); if(ma && !ma.classList.contains('hidden')) hideModal('admin');
      const mh = document.getElementById('modal-hlv-login'); if(mh && !mh.classList.contains('hidden')) hideModal('hlv');
    }
  });

  document.querySelectorAll('.modal-close').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const target = btn.dataset.close;
      if(target) hideModal(target);
    });
  });

  const toastClose = document.getElementById('toast-close');
  if(toastClose){
    toastClose.addEventListener('click', ()=> hideToast());
  }
}

// --- Admin login handler ---
async function onAdminLogin(e){
  e.preventDefault();
  const username = document.getElementById('admin-username').value.trim();
  const password = document.getElementById('admin-password').value.trim();
  try{
    const res = await fetch(API.adminLogin, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ username, password })
    });
    if(!res.ok){
      const data = await res.json().catch(()=>null);
      showToast({ title:'Đăng nhập thất bại', message: data?.error || 'Sai tài khoản hoặc mật khẩu admin.', type:'error' });
      return;
    }
    // success: đánh dấu đã đăng nhập admin trên trình duyệt
    localStorage.setItem('isAdmin', 'true');
    hideModal('admin');
    showToast({ title:'Đăng nhập admin thành công', message:'Đang chuyển tới trang admin...', type:'success' });
    // chuyển sang trang admin
    window.location.href = 'admin.html';
  }catch(err){
    console.error('Admin login error', err);
    showToast({ title:'Không kết nối được server', message:'Vui lòng thử lại sau.', type:'error' });
  }
}

// --- HLV login handler: gọi API /api/hlv-login ---
async function onHlvLogin(e){
  e.preventDefault();
  const username = document.getElementById('hlv-username').value.trim();
  const password = document.getElementById('hlv-password').value.trim();

  try{
    const res = await fetch(API.hlvLogin, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ username, password })
    });
    if(res.ok){
      const data = await res.json().catch(()=>null) || {};
      try{
        if(data?.hlv_id){
          localStorage.setItem('hlvId', String(data.hlv_id));
        }
        if(data?.ten_hlv){
          localStorage.setItem('hlvName', data.ten_hlv);
        }
      }catch(errStorage){/* ignore */}
      hideModal('hlv');
      showToast({ title:'Đăng nhập HLV thành công', message:'Đang chuyển tới trang HLV...', type:'success' });
      if(data?.hlv_id){
        window.location.href = `hlv.html?hlv_id=${encodeURIComponent(data.hlv_id)}`;
      }else{
        window.location.href = 'hlv.html';
      }
      return;
    }

    // Nếu API trả lỗi (ví dụ 404), thử fallback theo quy ước pt{hlv_id} / 1
    if(res.status === 404 || res.status === 500){
      const match = /^pt(\d+)$/.exec(username.toLowerCase());
      const hlvId = match ? Number(match[1]) : 0;
      if(password === '1' && hlvId){
        try{
          localStorage.setItem('hlvId', String(hlvId));
          localStorage.setItem('hlvName', `HLV ${hlvId}`);
        }catch(errStorage){/* ignore */}
        hideModal('hlv');
        showToast({ title:'Đăng nhập HLV (fallback)', message:`Đang chuyển tới trang HLV ${hlvId}...`, type:'success' });
        window.location.href = `hlv.html?hlv_id=${encodeURIComponent(hlvId)}`;
        return;
      }
    }

    const data = await res.json().catch(()=>null);
    showToast({ title:'Đăng nhập HLV thất bại', message: data?.error || 'Sai tài khoản hoặc mật khẩu HLV.', type:'error' });
  }catch(err){
    console.error('HLV login error', err);
    // Nếu fetch hoàn toàn thất bại, cũng dùng fallback pt{hlv_id}/1
    const match = /^pt(\d+)$/.exec(username.toLowerCase());
    const hlvId = match ? Number(match[1]) : 0;
    if(password === '1' && hlvId){
      try{
        localStorage.setItem('hlvId', String(hlvId));
        localStorage.setItem('hlvName', `HLV ${hlvId}`);
      }catch(errStorage){/* ignore */}
      hideModal('hlv');
      showToast({ title:'Đăng nhập HLV (offline)', message:`Đang chuyển tới trang HLV ${hlvId}...`, type:'success' });
      window.location.href = `hlv.html?hlv_id=${encodeURIComponent(hlvId)}`;
      return;
    }
    showToast({ title:'Không kết nối được server', message:'Vui lòng thử lại sau.', type:'error' });
  }
}

// --- Auth: register / login (uses real API if exists, else mock) ---
async function onRegister(e){
  e.preventDefault();
  const username = document.getElementById('reg-username').value.trim();
  const password = document.getElementById('reg-password').value.trim();
  const confirmPassword = document.getElementById('reg-password-confirm').value.trim();
  const ten = document.getElementById('reg-name').value.trim();
  const tuoi = parseInt(document.getElementById('reg-age').value,10);
  const phone = document.getElementById('reg-phone').value.trim();
  if(password !== confirmPassword){
    alert('Mật khẩu xác nhận chưa khớp.');
    return;
  }
  try {
    const res = await fetch(API.register, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({username,password,ten,tuoi,phone})
    });
    if(!res.ok){
      const data = await res.json().catch(()=>null);
      alert(data?.error || 'Đăng ký thất bại, vui lòng thử lại.');
      return;
    }
    const data = await res.json();
    state.currentUser = data;
    hideModal('register');
    renderUserState();
    alert('Đăng ký thành công, đã đăng nhập!');
  } catch(err){
    console.error('Register error', err);
    alert('Không kết nối được tới server. Vui lòng thử lại sau.');
  }
}

async function onLogin(e){
  e.preventDefault();
  const username = document.getElementById('login-username').value.trim();
  const password = document.getElementById('login-password').value.trim();

  try {
    const res = await fetch(API.login, {
      method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({username,password})
    });
    if(!res.ok){
      const data = await res.json().catch(()=>null);
      alert(data?.error || 'Đăng nhập thất bại, vui lòng kiểm tra lại.');
      return;
    }
    const data = await res.json();
    state.currentUser = data;
    hideModal('login');
    renderUserState();
  } catch(err){
    console.error('Login error', err);
    alert('Không kết nối được tới server. Vui lòng thử lại sau.');
  }
}

function logout(){
  state.currentUser = null;
  renderUserState();
  closeSidebarWindow();
  showToast({ title:'Đã đăng xuất', message:'Hẹn gặp lại bạn!', type:'success' });
}

// --- Render user state ---
function renderUserState(){
  const nick = document.getElementById('user-nickname');
  const userArea = document.getElementById('user-area');
  const accountName = document.getElementById('account-name');
  const accountPhone = document.getElementById('account-phone');
  const accountDob = document.getElementById('account-dob');
  if(state.currentUser){
    userArea.classList.add('hidden');
    nick.classList.remove('hidden');
    document.getElementById('nick-name-text').innerText = state.currentUser.username;
    document.getElementById('profile-name').innerText = state.currentUser.ten || 'Thành viên';
    document.getElementById('profile-username').innerText = state.currentUser.username;
    if(accountName) accountName.innerText = state.currentUser.ten || 'Thành viên';
    if(accountPhone) accountPhone.innerText = state.currentUser.sodienthoai || '---';
    if(accountDob) accountDob.innerText = state.currentUser.tuoi ? `${state.currentUser.tuoi} tuổi` : '---';
    // show profile default
    showSection('welcome');
    setSidebarActiveById(null);
    loadPersonalInfo();
  } else {
    userArea.classList.remove('hidden');
    nick.classList.add('hidden');
    document.getElementById('profile-name').innerText = 'Khách';
    document.getElementById('profile-username').innerText = '';
    if(accountName) accountName.innerText = 'Khách';
    if(accountPhone) accountPhone.innerText = '---';
    if(accountDob) accountDob.innerText = '---';
    showSection('welcome');
    setSidebarActiveById(null);
  }
}

// --- Load packages either from backend or mock ---
async function loadSettings(){
  try{
    const response = await fetch(API.settings);
    if(!response.ok) throw new Error('Không tải được settings');
    const settings = await response.json();
    state.settings = settings;
    applySettings(settings);
  }catch(e){
    console.warn('loadSettings error, using defaults:', e);
    // Use defaults if API fails
    state.settings = {
      gym_name: 'M1-GYM',
      gym_slogan: 'Fitness & Training',
      gym_logo: 'assets/images/logo.svg',
      welcome_message: 'Chào mừng đến M1-GYM',
      system_notification: '',
      operating_hours: { open: '06:00', close: '22:00' },
      contact_phone: '',
      contact_email: '',
      address: '',
      qr_bank_code: 'bidv',
      qr_account_number: '10032004999',
      qr_account_name: 'NGUYEN VAN THAI',
      qr_additional_info: 'Thanh toan goi tap M1-GYM'
    };
    applySettings(state.settings);
  }
}

function applySettings(settings){
  if(!settings) return;
  
  // Update page title
  if(settings.gym_name){
    document.title = `${settings.gym_name} - Trang chủ`;
  }
  
  // Update brand logo
  const brandIcon = document.querySelector('.brand-icon');
  if(brandIcon && settings.gym_logo){
    brandIcon.src = settings.gym_logo;
    brandIcon.alt = `${settings.gym_name || 'M1-GYM'} Logo`;
  }
  
  // Update brand text
  const brandTextStrong = document.querySelector('.brand-text strong');
  const brandTextSmall = document.querySelector('.brand-text small');
  if(brandTextStrong && settings.gym_name){
    brandTextStrong.textContent = settings.gym_name;
  }
  if(brandTextSmall && settings.gym_slogan){
    brandTextSmall.textContent = settings.gym_slogan;
  }
  
  // Update welcome message
  const welcomeH3 = document.querySelector('#welcome h3');
  if(welcomeH3 && settings.welcome_message){
    welcomeH3.textContent = settings.welcome_message;
  }
  
  // Show system notification if exists
  const mainContent = document.getElementById('main-content');
  if(mainContent && settings.system_notification && settings.system_notification.trim()){
    let notificationEl = document.getElementById('system-notification');
    if(!notificationEl){
      notificationEl = document.createElement('div');
      notificationEl.id = 'system-notification';
      notificationEl.className = 'card section system-notification';
      notificationEl.style.cssText = 'background: linear-gradient(135deg, #e53935 0%, #c62828 100%); color: white; margin-bottom: 16px;';
      mainContent.insertBefore(notificationEl, mainContent.firstChild);
    }
    notificationEl.innerHTML = `
      <div style="display: flex; align-items: center; gap: 12px;">
        <span style="font-size: 24px;">📢</span>
        <div style="flex: 1;">
          <strong style="display: block; margin-bottom: 4px;">Thông báo hệ thống</strong>
          <p style="margin: 0; opacity: 0.95;">${settings.system_notification}</p>
        </div>
        <button id="close-notification" style="background: rgba(255,255,255,0.2); border: none; color: white; width: 32px; height: 32px; border-radius: 50%; cursor: pointer; font-size: 20px; line-height: 1;">&times;</button>
      </div>
    `;
    const closeBtn = notificationEl.querySelector('#close-notification');
    if(closeBtn){
      closeBtn.addEventListener('click', () => {
        notificationEl.remove();
      });
    }
  }else{
    const notificationEl = document.getElementById('system-notification');
    if(notificationEl) notificationEl.remove();
  }

  // Refresh QR preview with latest settings
  updateQrPreview();
}

function updateQrPreview(amount, pkgName){
  const qrImg = document.getElementById('qr-preview');
  const amountText = document.getElementById('qr-amount-text');
  const qrNote = document.getElementById('qr-note-text');
  if(!qrImg || !amountText) return;
  const qrSettings = state.settings || {};
  // Luôn dùng ảnh QR tĩnh từ assets
  qrImg.src = '/assets/images/qr-custom.png';

  // Cập nhật phần text số tiền ở dưới
  if(amount){
    const rounded = Math.round(Number(amount) || 0);
    if(rounded > 0){
      amountText.innerText = `Số tiền: ${formatMoney(rounded)}`;
    }else{
      amountText.innerText = 'Chưa xác định số tiền.';
    }
  }else{
    amountText.innerText = 'Chọn gói để hiển thị số tiền.';
  }

  // Ghi chú bên dưới (chủ TK, STK) nếu có cấu hình
  if(qrNote){
    const ownerText = qrSettings.qr_account_name ? `Chủ TK: ${qrSettings.qr_account_name}` : '';
    const accountNumber = qrSettings.qr_account_number || '';
    qrNote.innerText = accountNumber
      ? `${ownerText ? ownerText + ' • ' : ''}STK: ${accountNumber}`
      : '';
  }
}

async function loadPackages(){
  try{
    const res = await fetch(API.packages);
    if(!res.ok) throw new Error('Failed to load packages');
    const list = await res.json();
    state.packages = Array.isArray(list) ? list : [];
    renderPackages(state.packages);
  }catch(e){
    console.error('loadPackages error', e);
    alert('Không tải được danh sách gói tập. Vui lòng tải lại trang hoặc kiểm tra server.');
  }
}

function renderPackages(list){
  const grid = document.getElementById('packages-grid');
  const userGrid = document.getElementById('user-packages-grid');
  grid.innerHTML = '';
  if(userGrid) userGrid.innerHTML = '';
  list.forEach(pkg=>{
    const card = document.createElement('div');
    card.className = 'package-card';
    const imgSrc = pkg.image ? toAssetUrl(pkg.image) : null;
    const imgBlock = imgSrc ? `<div class="package-thumb"><img src="${imgSrc}" alt="${pkg.ten_goi}"/></div>` : '';
    const markup = `${imgBlock}<h4>${pkg.ten_goi}</h4>
      <p>${pkg.mo_ta || ''}</p>
      <div><strong>${formatMoney(pkg.gia)}</strong></div>
      <div class="package-actions">
        <button class="btn btn-primary" onclick="selectPlanFromCard(${pkg.goi_id})">Chọn gói này</button>
        <button class="btn btn-outline" onclick="viewPackage(${pkg.goi_id})">Chi tiết</button>
      </div>`;
    card.innerHTML = markup;
    grid.appendChild(card);
    if(userGrid){
      const clone = document.createElement('div');
      clone.className = 'package-card';
      clone.innerHTML = markup;
      userGrid.appendChild(clone);
    }
  });
}

// map click trên card -> chọn plan tương ứng trong form mới
function selectPlanFromCard(goi_id){
  const form = document.getElementById('package-custom-form');
  if(!form){
    // fallback: vẫn cho phép flow cũ chạy nếu form chưa có
    startBooking(goi_id);
    return;
  }
  // tìm radio theo value (trùng goi_id ở HTML mới với các gói chuẩn)
  const planInput = form.querySelector(`input[name="plan"][value="${goi_id}"]`);
  if(planInput){
    planInput.checked = true;
    // kích hoạt lại tính toán / highlight
    planInput.dispatchEvent(new Event('change', { bubbles:true }));
  }
  // scroll tới form mới
  form.scrollIntoView({behavior:'smooth', block:'start'});
}

function toAssetUrl(path){
  if(!path) return '';
  if(/^https?:\/\//.test(path)) return path;
  if(path.startsWith('/')) return path;
  return '/' + path.replace(/^\.?\//,'');
}

// format money
function formatMoney(v){ return (Number(v)||0).toLocaleString('vi-VN',{style:'currency',currency:'VND'}); }

// start booking
function startBooking(goi_id, meta = {}){
  // find package from mock
  const pkg = (state.packages || []).find(p=>p.goi_id===goi_id);
  if(!pkg) return alert('Gói không tồn tại');
  state.selectedPackage = pkg;
  state.packageMeta = Object.keys(meta).length ? meta : null;
  document.getElementById('booking-flow').classList.remove('hidden');
  const price = meta.priceOverride || pkg.gia;
  const name = meta.planLabel || pkg.ten_goi;
  const infoList = [];
  if(meta.goal) infoList.push(`Mục tiêu: ${meta.goal}`);
  if(meta.readableStartDate || meta.startDate) infoList.push(`Bắt đầu: ${meta.readableStartDate || meta.startDate}`);
  if(meta.sessions) infoList.push(`${meta.sessions} buổi/tuần`);
  if(meta.addons && meta.addons.length) infoList.push(`Tiện ích: ${meta.addons.join(', ')}`);
  if(meta.coachPreference) infoList.push(`HLV ưu tiên: ${meta.coachPreference}`);
  const infoHtml = infoList.length ? `<br/><small>${infoList.join('<br/>')}</small>` : '';
  document.getElementById('selected-package').innerHTML = `<strong>${name}</strong> - ${formatMoney(price)}${infoHtml}`;
  document.getElementById('cart-details').innerHTML = `${name} - ${formatMoney(price)}${infoHtml}`;
  // reset steps
  document.getElementById('step-2').classList.add('hidden');
  document.getElementById('step-3').classList.add('hidden');
  resetScheduleSelection();
  // load hlv list
  renderHlvList();
}

function cancelBooking(){
  state.selectedPackage = null;
  state.selectedHlv = null;
  state.selectedLich = null;
  state.selectedDate = null;
  state.selectedTimeSlot = null;
  state.selectedScheduleLabel = null;
  state.packageMeta = null;
  document.getElementById('booking-flow').classList.add('hidden');
  document.getElementById('cart-details').innerText = 'Chưa chọn gói.';
  resetScheduleSelection();
}

function renderHlvList(){
  const div = document.getElementById('hlv-list');
  div.innerHTML = '';
  const render = (list)=>{
    div.innerHTML = '';
    state.hlvList = Array.isArray(list) ? list : [];
    list.forEach(h=>{
      const item = document.createElement('div');
      item.className = 'hlv-item';
      const imgSrc = h.anh_url ? toAssetUrl(h.anh_url) : '';
      item.innerHTML = `<div class="hlv-photo">${imgSrc? `<img src="${imgSrc}" style="max-width:100%;height:70px;object-fit:cover;border-radius:6px"/>` : 'Ảnh'}</div>
        <div>${h.ten_hlv}</div>
        <div style="font-size:12px">${h.chuyen_mon||''}</div>
        <div style="margin-top:6px"><button class="btn btn-outline" onclick="chooseHlv(${h.hlv_id})">Chọn</button></div>`;
      div.appendChild(item);
    });
  };
  // load từ API
  fetch('/api/hlv')
    .then(r=> r.ok ? r.json(): Promise.reject())
    .then(render)
    .catch(err=>{
      console.error('load HLV error', err);
      div.innerText = 'Không tải được danh sách HLV.';
    });
}

function chooseHlv(hlv_id){
  const hlv = (state.hlvList || []).find(h=>h.hlv_id===hlv_id);
  if(!hlv) return;
  state.selectedHlv = hlv;
  alert('Đã chọn HLV: ' + hlv.ten_hlv);
}

// step 3
function onToStep3(){
  const sel = document.getElementById('select-lich').value;
  const dateValue = state.selectedDate;
  const slot = state.selectedTimeSlot;
  if(!dateValue){
    alert('Vui lòng chọn ngày tập.');
    return;
  }
  if(!slot){
    alert('Vui lòng chọn giờ mong muốn.');
    return;
  }
  state.selectedLich = sel;
  if(!state.selectedHlv) return alert('Chọn HLV ở B2 trước');
  document.getElementById('step-2').classList.add('hidden');
  document.getElementById('step-3').classList.remove('hidden');
  const meta = state.packageMeta || {};
  const pkgName = meta.planLabel || state.selectedPackage.ten_goi;
  const price = Number(meta.priceOverride || state.selectedPackage.gia) || 0;
  const addonsText = meta.addons && meta.addons.length ? meta.addons.join(', ') : 'Không';
  const startDate = meta.readableStartDate || meta.startDate || 'Chưa chọn';
  const notes = meta.notes ? `\nGhi chú: ${meta.notes}` : '';
  const dateReadable = formatDateReadable(dateValue);
  state.selectedScheduleLabel = `${dateReadable} • ${slot} (${sel})`;
  document.getElementById('pay-summary').innerText =
    `${pkgName} — ${formatMoney(price)}\nLịch: ${state.selectedScheduleLabel}\nHLV: ${state.selectedHlv.ten_hlv}\nMục tiêu: ${meta.goal || '---'}\nBắt đầu: ${startDate}\nTiện ích: ${addonsText}\nBuổi/tuần: ${meta.sessions || '---'}${notes}`;
  updateQrPreview(price, pkgName);
}

// confirm payment / create booking -> write to mock or call API
async function confirmPayment(){
  if(!state.currentUser) return alert('Bạn cần đăng nhập để đặt gói.');
  const payMethod = document.querySelector('input[name="pay-method"]:checked').value;
  const finalPrice = state.packageMeta?.priceOverride || state.selectedPackage.gia;
  const lichText = state.selectedScheduleLabel || state.selectedLich || '';
  if(!state.selectedDate || !state.selectedTimeSlot){
    alert('Thiếu thông tin lịch. Vui lòng chọn ngày và khung giờ.');
    return;
  }
  // Attempt API
  try{
    const payload = {
      account_id: state.currentUser.account_id,
      goi_id: state.selectedPackage.goi_id,
      lich: lichText,
      hlv_id: state.selectedHlv.hlv_id,
      pay_method: payMethod,
      schedule_date: state.selectedDate,
      time_slot: state.selectedTimeSlot,
      meta: state.packageMeta || null,
      quoted_price: finalPrice
    };
    const res = await fetch(API.book, {
      method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)
    });
    if(res.ok){
      alert('Đặt gói thành công (API).');
      // refresh personal info
      loadPersonalInfo();
      cancelBooking();
      return;
    }
  }catch(e){ /* fallback */ }
  alert('Đặt gói thất bại. Vui lòng thử lại sau.');
}

// --- Personal info load & profile edit ---
function loadPersonalInfo(){
  if(!state.currentUser) return;
  const account_id = state.currentUser.account_id;
  (async ()=>{
    try{
      const res = await fetch(`/api/profile?account_id=${encodeURIComponent(account_id)}`);
      if(!res.ok) throw new Error('Failed to load profile');
      const data = await res.json();
      const kh = data.kh;
      const pkg = data.pkg;
      const hlv = data.hlv;
      const payments = data.payments || [];
      const schedules = data.schedules || [];
      renderProfileDetails({ kh, pkg, hlv, payments, schedules });
    }catch(e){
      console.error('loadPersonalInfo error', e);
    }
  })();
}

function renderProfileDetails({ kh, pkg, hlv, payments = [], schedules = [] }){
  const scheduleInfo = document.getElementById('schedule-info');
  const scheduleList = document.getElementById('schedule-list');
  const hlvBox = document.getElementById('my-hlv');
  const nextSchedule = schedules.length ? schedules[0] : null;
  const payStatus = kh?.trang_thai_thanh_toan || 'Chưa thanh toán';
  const isDebt = payStatus !== 'Đã thanh toán';
  if(kh && kh.da_dang_ky_goi){
    if(scheduleInfo){
      if(nextSchedule){
        const dateText = formatDateReadable(nextSchedule.ngay);
        const timeText = formatTimeRangeFromStart(nextSchedule.gio_bat_dau);
        scheduleInfo.innerHTML = `Lịch sắp tới: <strong>${dateText}</strong> • ${timeText}<br/>Trạng thái lịch: ${nextSchedule.trang_thai || 'Đang chờ'}<br/>Thanh toán: <strong>${payStatus}</strong>`;
      } else {
        scheduleInfo.innerHTML = `Gói: <strong>${pkg?pkg.ten_goi:'-'}</strong><br/>Lịch: ${kh.lich_tap || '-'}<br/>Thanh toán: <strong>${payStatus}</strong>`;
      }
    }
    if(hlvBox) hlvBox.innerHTML = hlv ? `<div><strong>${hlv.ten_hlv}</strong><div class="hlv-photo" style="height:100px">${hlv.anh_url?'<img src="'+hlv.anh_url+'" style="max-width:100%;height:100%;object-fit:cover">':'Ảnh'}</div></div>` : 'Chưa chọn HLV';
  } else {
    if(scheduleInfo) scheduleInfo.innerText = 'Bạn chưa đăng ký gói.';
    if(hlvBox) hlvBox.innerText = 'Chưa chọn HLV.';
  }
  if(scheduleList){
    scheduleList.innerHTML = '';
    if(schedules.length){
      schedules.slice(0, 6).forEach(item=>{
        const li = document.createElement('li');
        const dateText = formatDateReadable(item.ngay);
        const timeText = formatTimeRangeFromStart(item.gio_bat_dau);
        li.innerHTML = `<span><strong>${dateText}</strong> • ${timeText}</span><span>${item.trang_thai || ''}</span>`;
        scheduleList.appendChild(li);
      });
    } else {
      const li = document.createElement('li');
      li.textContent = 'Chưa có lịch đặt nào.';
      scheduleList.appendChild(li);
    }
  }
  const payDiv = document.getElementById('payment-list');
  if(payDiv){
    payDiv.innerHTML = '';
    if(payments.length){
      payments.forEach(p=>{
        const el = document.createElement('div');
        el.style.padding='8px';
        el.style.borderBottom='1px solid #eee';
        el.innerHTML = `<div><strong>${p.ten_goi||'Chưa có gói'}</strong> - ${formatMoney(p.tong_tien)}</div>
          <div>Trạng thái: <span style="color:${p.trang_thai==='Đã thanh toán'?'green':'red'}">${p.trang_thai}</span></div>`;
        payDiv.appendChild(el);
      });
    } else {
      payDiv.innerText = 'Không có bản ghi thanh toán.';
    }
  }
  const mini = document.getElementById('payment-list-mini');
  if(mini){
    mini.innerHTML = '';
    if(payments.length){
      payments.slice(0,3).forEach(p=>{
        const item = document.createElement('div');
        item.innerHTML = `<strong>${p.ten_goi||'Gói'}</strong> - ${formatMoney(p.tong_tien)}<br/><small>${p.trang_thai}</small>`;
        mini.appendChild(item);
      });
    } else {
      mini.innerText = 'Chưa có thanh toán.';
    }
  }
  const nameEl = document.getElementById('profile-package-name');
  if(nameEl){
    if(kh && kh.da_dang_ky_goi){
      nameEl.innerText = pkg?pkg.ten_goi:'Gói đã đăng ký';
      const statusText = document.getElementById('profile-package-status');
      if(statusText) statusText.innerText = isDebt ? 'Đang nợ phí, vui lòng thanh toán.' : 'Gói đang hoạt động';
      const pkgStatus = document.getElementById('package-status');
      if(pkgStatus) pkgStatus.innerText = isDebt ? 'Đang nợ' : 'Còn hạn';
    } else {
      nameEl.innerText = 'Chưa đăng ký';
      const statusText = document.getElementById('profile-package-status');
      if(statusText) statusText.innerText = 'Vui lòng đăng ký gói';
      const pkgStatus = document.getElementById('package-status');
      if(pkgStatus) pkgStatus.innerText = 'Chưa kích hoạt';
    }
    const startEl = document.getElementById('package-start');
    const endEl = document.getElementById('package-end');
    const ptEl = document.getElementById('package-pt');
    if(startEl) startEl.innerText = kh?.ngay_bat_dau || '--/--/----';
    if(endEl) endEl.innerText = kh?.ngay_ket_thuc || '--/--/----';
    if(ptEl) ptEl.innerText = kh && kh.buoi_pt_con_lai !== undefined ? kh.buoi_pt_con_lai : '0';
  }
  const editName = document.getElementById('edit-name');
  const editAge = document.getElementById('edit-age');
  if(editName) editName.value = state.currentUser.ten || '';
  if(editAge) editAge.value = state.currentUser.tuoi || '';
}

function onProfileEdit(e){
  e.preventDefault();
  if(!state.currentUser) return alert('Đăng nhập để chỉnh sửa.');
  const newName = document.getElementById('edit-name').value.trim();
  const newAge = parseInt(document.getElementById('edit-age').value,10);
  const newPassword = document.getElementById('edit-password').value.trim();

  (async ()=>{
    try{
      const payload = { account_id: state.currentUser.account_id };
      if(newName) payload.ten = newName;
      if(newAge) payload.tuoi = newAge;
      if(newPassword) payload.password = newPassword;
      const res = await fetch('/api/profile', { method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
      if(!res.ok){
        const data = await res.json().catch(()=>null);
        alert(data?.error || 'Cập nhật thông tin thất bại.');
        return;
      }
      const updated = await res.json();
      state.currentUser = { ...state.currentUser, ...updated };
      renderUserState();
      alert('Cập nhật thông tin thành công.');
    }catch(err){
      console.error('profile update error', err);
      alert('Không kết nối được tới server. Vui lòng thử lại sau.');
    }
  })();
}

// --- helpers view sections ---
function showSection(id){
  const sections = ['welcome','profile-edit','profile-schedule','profile-hlv','payment-table'];
  sections.forEach(s => document.getElementById(s).classList.add('hidden'));
  document.getElementById(id).classList.remove('hidden');
}

function setSidebarActiveById(btnId){
  document.querySelectorAll('.sidebar-link').forEach(btn=>{
    if(!btnId){
      btn.classList.remove('active');
      return;
    }
    btn.classList.toggle('active', btn.id === btnId);
  });
}

function viewPackage(goi_id){
  const pkg = LocalMock.getPackages().find(p=>p.goi_id===goi_id);
  alert(`Chi tiết: ${pkg.ten_goi}\nGiá: ${formatMoney(pkg.gia)}\nMô tả: ${pkg.mo_ta}`);
}

function scrollToPackages(){
  const section = document.getElementById('packages-section');
  if(section){
    section.scrollIntoView({behavior:'smooth'});
  }
}

// --- Schedule picker helpers ---
function initSchedulePicker(){
  const dateInput = document.getElementById('select-date');
  const slotList = document.getElementById('time-slot-list');
  if(!dateInput || !slotList) return;
  const today = new Date().toISOString().split('T')[0];
  dateInput.min = today;
  if(!dateInput.value){
    dateInput.value = today;
  }
  state.selectedDate = dateInput.value;
  dateInput.addEventListener('change', ()=>{
    state.selectedDate = dateInput.value;
  });
  slotList.innerHTML = '';
  DEFAULT_TIME_SLOTS.forEach((slot, index)=>{
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'time-slot';
    btn.dataset.slot = slot;
    btn.textContent = slot;
    btn.addEventListener('click', ()=>{
      state.selectedTimeSlot = slot;
      slotList.querySelectorAll('.time-slot').forEach(el=> el.classList.toggle('active', el === btn));
    });
    slotList.appendChild(btn);
    if(index === 0){
      btn.classList.add('active');
      state.selectedTimeSlot = slot;
    }
  });
}

function resetScheduleSelection(){
  const slotList = document.getElementById('time-slot-list');
  if(slotList){
    const buttons = Array.from(slotList.querySelectorAll('.time-slot'));
    buttons.forEach((el, idx)=>{
      const isDefault = idx === 0;
      el.classList.toggle('active', isDefault);
      if(isDefault){
        state.selectedTimeSlot = el.dataset.slot || el.textContent;
      }
    });
  }
  const dateInput = document.getElementById('select-date');
  const today = new Date().toISOString().split('T')[0];
  if(dateInput){
    if(!dateInput.value){
      dateInput.value = today;
    }
    if(dateInput.value < today){
      dateInput.value = today;
    }
    state.selectedDate = dateInput.value;
  }
  if(!slotList){
    state.selectedTimeSlot = DEFAULT_TIME_SLOTS[0] || null;
  }
  state.selectedScheduleLabel = null;
}

function formatDateReadable(dateStr){
  if(!dateStr) return '---';
  const date = new Date(dateStr + 'T00:00:00');
  if(Number.isNaN(date.getTime())) return dateStr;
  return date.toLocaleDateString('vi-VN', { weekday:'short', day:'2-digit', month:'2-digit', year:'numeric' });
}

function formatTimeRangeFromStart(startTime){
  if(!startTime) return '--:--';
  const [h = '0', m = '0'] = startTime.split(':');
  const baseline = new Date();
  baseline.setHours(Number(h), Number(m), 0, 0);
  const end = new Date(baseline.getTime() + 2 * 60 * 60 * 1000);
  const opts = { hour: '2-digit', minute: '2-digit' };
  return `${baseline.toLocaleTimeString('vi-VN', opts)} - ${end.toLocaleTimeString('vi-VN', opts)}`;
}

// --- Sidebar mini panel ---
const SIDEBAR_WINDOW_SECTIONS = {
  profile: { title: 'Thông tin & Sửa', sectionId: 'profile-edit' },
  schedule: { title: 'Lịch tập', sectionId: 'profile-schedule' },
  hlv: { title: 'HLV của tôi', sectionId: 'profile-hlv' },
  payment: { title: 'Thanh toán', sectionId: 'payment-table' }
};

let sidebarWindowState = {
  key: null,
  node: null,
  parent: null,
  nextSibling: null,
  wasHidden: true
};

function openSidebarWindow(type){
  const config = SIDEBAR_WINDOW_SECTIONS[type];
  const layer = document.getElementById('sidebar-window');
  const titleEl = document.getElementById('sidebar-window-title');
  const body = document.getElementById('sidebar-window-content');
  if(!config || !layer || !titleEl || !body) return;

  // restore any previous section
  restoreSidebarSection();

  const section = document.getElementById(config.sectionId);
  if(!section) return;

  sidebarWindowState = {
    key: type,
    node: section,
    parent: section.parentElement,
    nextSibling: section.nextSibling,
    wasHidden: section.classList.contains('hidden')
  };

  section.classList.remove('hidden');
  body.innerHTML = '';
  body.appendChild(section);

  titleEl.textContent = config.title;
  layer.classList.remove('hidden');
}

function closeSidebarWindow(){
  restoreSidebarSection();
  const layer = document.getElementById('sidebar-window');
  if(layer){
    layer.classList.add('hidden');
  }
  const body = document.getElementById('sidebar-window-content');
  if(body){
    body.innerHTML = '<p>Chọn một danh mục bên trái để xem chi tiết.</p>';
  }
}

function restoreSidebarSection(){
  const ctx = sidebarWindowState;
  if(!ctx.node || !ctx.parent) return;
  const section = ctx.node;
  if(ctx.nextSibling){
    ctx.parent.insertBefore(section, ctx.nextSibling);
  } else {
    ctx.parent.appendChild(section);
  }
  if(ctx.wasHidden){
    section.classList.add('hidden');
  } else {
    section.classList.remove('hidden');
  }
  sidebarWindowState = { key:null, node:null, parent:null, nextSibling:null, wasHidden:true };
}
