

CREATE DATABASE IF NOT EXISTS gym_management
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE gym_management;
SET NAMES utf8mb4;

-- -------------------------------------------------------------------
-- Core tables
-- -------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS tai_khoan (
  account_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  ten VARCHAR(150) NOT NULL,
  tuoi INT CHECK (tuoi BETWEEN 10 AND 120),
  sodienthoai VARCHAR(20),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS Goi_tap (
  goi_id INT AUTO_INCREMENT PRIMARY KEY,
  so_bang INT,
  ten_goi VARCHAR(150) NOT NULL,
  gia DECIMAL(12,2) NOT NULL,
  mo_ta TEXT,
  image VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Ensure legacy databases also có cột image (tránh lỗi Unknown column 'g.image')
-- Note: MySQL doesn't support IF NOT EXISTS for ALTER TABLE, so we'll handle this in application code
-- ALTER TABLE Goi_tap ADD COLUMN image VARCHAR(255);

CREATE TABLE IF NOT EXISTS HLV (
  hlv_id INT AUTO_INCREMENT PRIMARY KEY,
  ten_hlv VARCHAR(150) NOT NULL,
  kinh_nghiem INT,
  chuyen_mon VARCHAR(150),
  phone VARCHAR(20),
  anh_url VARCHAR(255),
  mo_ta TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS Khach_hang (
  kh_id INT AUTO_INCREMENT PRIMARY KEY,
  account_id INT NOT NULL,
  da_dang_ky_goi BOOLEAN DEFAULT FALSE,
  goi_id INT,
  hlv_id INT,
  lich_tap VARCHAR(50),
  ngay_bat_dau DATE,
  ngay_ket_thuc DATE,
  buoi_pt_con_lai INT DEFAULT 0,
  trang_thai_thanh_toan ENUM('Chưa thanh toán','Đã thanh toán') DEFAULT 'Chưa thanh toán',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (account_id) REFERENCES tai_khoan(account_id) ON DELETE CASCADE,
  FOREIGN KEY (goi_id) REFERENCES Goi_tap(goi_id) ON DELETE SET NULL,
  FOREIGN KEY (hlv_id) REFERENCES HLV(hlv_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS Thanh_toan (
  tt_id INT AUTO_INCREMENT PRIMARY KEY,
  account_id INT NOT NULL,
  ten VARCHAR(150),
  tuoi INT,
  ten_goi VARCHAR(150),
  tong_tien DECIMAL(12,2),
  trang_thai ENUM('Chưa thanh toán','Đã thanh toán') DEFAULT 'Chưa thanh toán',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (account_id) REFERENCES tai_khoan(account_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS Dat_lich (
  dat_id INT AUTO_INCREMENT PRIMARY KEY,
  account_id INT NOT NULL,
  hlv_id INT NOT NULL,
  ngay DATE,
  gio_bat_dau TIME,
  trang_thai ENUM('Đang chờ','Xác nhận','Hủy') DEFAULT 'Đang chờ',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (account_id) REFERENCES tai_khoan(account_id) ON DELETE CASCADE,
  FOREIGN KEY (hlv_id) REFERENCES HLV(hlv_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS system_settings (
  setting_id INT AUTO_INCREMENT PRIMARY KEY,
  setting_key VARCHAR(100) NOT NULL UNIQUE,
  setting_value TEXT,
  setting_type VARCHAR(50) DEFAULT 'text',
  description TEXT,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------------------------------
-- Seed data (matches LocalMock + frontend expectations)
-- -------------------------------------------------------------------

INSERT INTO tai_khoan (account_id, username, password, ten, tuoi, sodienthoai)
VALUES
  (1, 'tk1', 'pass1', 'Người dùng 1', 22, '0901000001'),
  (2, 'tk2', 'pass1', 'Người dùng 2', 25, '0901000002')
ON DUPLICATE KEY UPDATE
  username = VALUES(username),
  password = VALUES(password),
  ten = VALUES(ten),
  tuoi = VALUES(tuoi),
  sodienthoai = VALUES(sodienthoai);

INSERT INTO Goi_tap (goi_id, so_bang, ten_goi, gia, mo_ta, image)
VALUES
  (1, 1, 'Gói 1 tháng - Cơ bản', 300000.00, 'Gói tập không giới hạn trong 1 tháng - dành cho người mới', 'assets/images/package-1.svg'),
  (2, 2, 'Gói 1 tháng - Nâng cao', 400000.00, 'Gói 1 tháng với 2 buổi HLV', 'assets/images/package-2.svg'),
  (3, 3, 'Gói 3 tháng - Tiết kiệm', 800000.00, 'Gói 3 tháng - tiết kiệm', 'assets/images/package-3.svg'),
  (4, 4, 'Gói 6 tháng - Bạc', 1500000.00, 'Ưu đãi cao cho người luyện tập dài hạn', 'assets/images/package-4.svg'),
  (5, 5, 'Gói 12 tháng - Vàng', 2800000.00, 'Gói 12 tháng trọn gói', 'assets/images/package-5.svg'),
  (6, 6, 'Gói Sinh Viên 6 tháng', 1000000.00, 'Ưu đãi sinh viên', 'assets/images/package-6.svg'),
  (7, 7, 'Gói Tăng cơ 3 tháng', 900000.00, 'Tập trung tăng cơ, kèm HLV', 'assets/images/package-7.svg'),
  (8, 8, 'Gói Yoga 1 tháng', 350000.00, 'Yoga & phục hồi', 'assets/images/package-8.svg')
ON DUPLICATE KEY UPDATE
  ten_goi = VALUES(ten_goi),
  gia = VALUES(gia),
  mo_ta = VALUES(mo_ta),
  image = VALUES(image);

INSERT INTO HLV (hlv_id, ten_hlv, kinh_nghiem, chuyen_mon, phone, anh_url, mo_ta)
VALUES
  (1, 'Nguyễn Văn A', 5, 'Tăng cơ', '0905123456', 'assets/images/hlv-1.svg', 'HLV chuyên tăng cơ'),
  (2, 'Trần Thị B', 4, 'Yoga', '0912345678', 'assets/images/hlv-2.svg', 'HLV chuyên yoga'),
  (3, 'Lê Văn C', 6, 'Cardio', '0987654321', 'assets/images/hlv-3.svg', 'HLV chuyên cardio')
ON DUPLICATE KEY UPDATE
  ten_hlv = VALUES(ten_hlv),
  chuyen_mon = VALUES(chuyen_mon),
  phone = VALUES(phone),
  anh_url = VALUES(anh_url),
  mo_ta = VALUES(mo_ta);

INSERT INTO Khach_hang (kh_id, account_id, da_dang_ky_goi, goi_id, hlv_id, lich_tap, ngay_bat_dau, ngay_ket_thuc, buoi_pt_con_lai, trang_thai_thanh_toan)
VALUES
  (1, 1, TRUE, 3, 1, 'SÁNG (8-11)', '2025-09-01', '2025-12-01', 4, 'Đã thanh toán'),
  (2, 2, FALSE, NULL, NULL, NULL, NULL, NULL, 0, 'Chưa thanh toán')
ON DUPLICATE KEY UPDATE
  da_dang_ky_goi = VALUES(da_dang_ky_goi),
  goi_id = VALUES(goi_id),
  hlv_id = VALUES(hlv_id),
  lich_tap = VALUES(lich_tap),
  ngay_bat_dau = VALUES(ngay_bat_dau),
  ngay_ket_thuc = VALUES(ngay_ket_thuc),
  buoi_pt_con_lai = VALUES(buoi_pt_con_lai),
  trang_thai_thanh_toan = VALUES(trang_thai_thanh_toan);

INSERT INTO Thanh_toan (tt_id, account_id, ten, tuoi, ten_goi, tong_tien, trang_thai)
VALUES
  (1, 1, 'Người dùng 1', 22, 'Gói 3 tháng - Tiết kiệm', 800000.00, 'Đã thanh toán'),
  (2, 2, 'Người dùng 2', 25, '', 0.00, 'Chưa thanh toán')
ON DUPLICATE KEY UPDATE
  ten = VALUES(ten),
  tuoi = VALUES(tuoi),
  ten_goi = VALUES(ten_goi),
  tong_tien = VALUES(tong_tien),
  trang_thai = VALUES(trang_thai);

-- Optional sample booking entries
INSERT INTO Dat_lich (dat_id, account_id, hlv_id, ngay, gio_bat_dau, trang_thai)
VALUES
  (1, 1, 1, '2025-11-12', '08:30:00', 'Xác nhận'),
  (2, 1, 1, '2025-11-15', '09:00:00', 'Đang chờ')
ON DUPLICATE KEY UPDATE
  ngay = VALUES(ngay),
  gio_bat_dau = VALUES(gio_bat_dau),
  trang_thai = VALUES(trang_thai);

-- System settings default values
INSERT INTO system_settings (setting_key, setting_value, setting_type, description)
VALUES
  ('gym_name', 'M1-GYM', 'text', 'Tên phòng gym'),
  ('gym_slogan', 'Fitness & Training', 'text', 'Slogan phòng gym'),
  ('gym_logo', 'assets/images/logo.svg', 'text', 'Đường dẫn logo'),
  ('welcome_message', 'Chào mừng đến M1-GYM', 'text', 'Thông điệp chào mừng'),
  ('system_notification', '', 'text', 'Thông báo hệ thống'),
  ('holiday_schedule', '[]', 'json', 'Lịch nghỉ (JSON array)'),
  ('operating_hours', '{"open": "06:00", "close": "22:00"}', 'json', 'Giờ hoạt động'),
  ('contact_phone', '', 'text', 'Số điện thoại liên hệ'),
  ('contact_email', '', 'text', 'Email liên hệ'),
  ('address', '', 'text', 'Địa chỉ phòng gym'),
  ('qr_bank_code', 'bidv', 'text', 'Mã ngân hàng VietQR (vd: bidv, vcb, tpbank)'),
  ('qr_account_number', '10032004999', 'text', 'Số tài khoản nhận chuyển khoản'),
  ('qr_account_name', 'NGUYEN VAN THAI', 'text', 'Tên chủ tài khoản in trên QR'),
  ('qr_additional_info', 'Thanh toan goi tap M1-GYM', 'text', 'Nội dung chuyển khoản mặc định')
ON DUPLICATE KEY UPDATE
  setting_value = VALUES(setting_value),
  description = VALUES(description);

COMMIT;

