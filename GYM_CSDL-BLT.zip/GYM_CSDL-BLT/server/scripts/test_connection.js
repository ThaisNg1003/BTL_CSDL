// Script to test database connection
import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load .env
dotenv.config({ path: path.resolve(__dirname, '../../.env') });

// Database configuration
const config = {
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'Thai1003@',
  database: process.env.DB_NAME || 'gym_management',
  multipleStatements: true,
  charset: 'utf8mb4_general_ci'
};

async function testConnection() {
  let connection;
  try {
    console.log('🔌 Đang kiểm tra kết nối database...');
    console.log(`   Host: ${config.host}`);
    console.log(`   Port: ${config.port}`);
    console.log(`   User: ${config.user}`);
    console.log(`   Database: ${config.database}`);
    console.log('');
    
    connection = await mysql.createConnection(config);
    console.log('✅ Kết nối database thành công!');
    
    // Test query
    const [rows] = await connection.query('SELECT DATABASE() as db, VERSION() as version');
    console.log(`📊 Database hiện tại: ${rows[0].db}`);
    console.log(`📦 MySQL Version: ${rows[0].version}`);
    
    // Check tables
    const [tables] = await connection.query(`
      SELECT COUNT(*) as count 
      FROM information_schema.tables 
      WHERE table_schema = ?
    `, [config.database]);
    
    console.log(`📋 Số bảng trong database: ${tables[0].count}`);
    
    if (tables[0].count === 0) {
      console.log('');
      console.log('⚠️  Database chưa có bảng nào!');
      console.log('💡 Chạy lệnh sau để import database:');
      console.log('   npm run import-db');
    } else {
      // List tables
      const [tableList] = await connection.query(`
        SELECT table_name 
        FROM information_schema.tables 
        WHERE table_schema = ?
        ORDER BY table_name
      `, [config.database]);
      
      console.log('');
      console.log('📋 Danh sách bảng:');
      if(Array.isArray(tableList) && tableList.length > 0){
        tableList.forEach((table, index) => {
          const tableName = table.table_name || table.TABLE_NAME || 'Unknown';
          console.log(`   ${index + 1}. ${tableName}`);
        });
      }else{
        console.log('   (Không có bảng nào)');
      }
    }
    
    console.log('');
    console.log('✅ Database đã sẵn sàng!');
    
  } catch (error) {
    console.error('');
    console.error('❌ Lỗi kết nối database:', error.message);
    console.error('');
    
    if (error.code === 'ECONNREFUSED') {
      console.error('💡 MySQL service chưa chạy hoặc sai host/port');
      console.error('   - Kiểm tra MySQL service có đang chạy không');
      console.error('   - Kiểm tra host và port trong file .env');
    } else if (error.code === 'ER_ACCESS_DENIED_ERROR') {
      console.error('💡 Sai username hoặc password');
      console.error('   - Kiểm tra lại DB_USER và DB_PASSWORD trong file server/.env');
    } else if (error.code === 'ER_BAD_DB_ERROR') {
      console.error('💡 Database chưa được tạo');
      console.error('   - Chạy lệnh: npm run import-db');
      console.error('   - Hoặc tạo database thủ công: CREATE DATABASE gym_management;');
    } else {
      console.error('💡 Lỗi không xác định. Vui lòng kiểm tra lại cấu hình.');
    }
    
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

testConnection();

