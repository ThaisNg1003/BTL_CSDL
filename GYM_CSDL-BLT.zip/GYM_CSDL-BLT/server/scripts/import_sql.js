// Script to import database
import mysql from 'mysql2/promise';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load .env
dotenv.config({ path: path.resolve(__dirname, '../../.env') });

// Database configuration
const config = {
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'Thai1003@',
  multipleStatements: true,
  charset: 'utf8mb4_general_ci'
};

async function importDatabase() {
  let connection;
  try {
    console.log('🔌 Đang kết nối với MySQL...');
    connection = await mysql.createConnection(config);
    console.log('✅ Đã kết nối với MySQL');

    // Read SQL file
    const sqlFile = path.join(__dirname, '../../gym_management.sql');
    console.log(`📖 Đang đọc file: ${sqlFile}`);
    
    if (!fs.existsSync(sqlFile)) {
      throw new Error(`File không tồn tại: ${sqlFile}`);
    }

    const sql = fs.readFileSync(sqlFile, 'utf8');
    console.log('📝 Đang import database...');

    // Execute SQL
    await connection.query(sql);
    console.log('✅ Đã import database thành công!');
    console.log('📊 Database: gym_management');
    console.log('📋 Các bảng đã được tạo và dữ liệu mẫu đã được thêm vào.');

  } catch (error) {
    console.error('❌ Lỗi khi import database:', error.message);
    if (error.code === 'ECONNREFUSED') {
      console.error('💡 Hãy đảm bảo MySQL đang chạy và thông tin kết nối đúng.');
      console.error('   Kiểm tra: MySQL Service có đang chạy không?');
    } else if (error.code === 'ER_ACCESS_DENIED_ERROR') {
      console.error('💡 Sai username hoặc password. Vui lòng kiểm tra lại.');
      console.error('   Tạo file server/.env với thông tin đúng:');
      console.error('   DB_HOST=localhost');
      console.error('   DB_PORT=3306');
      console.error('   DB_USER=root');
      console.error('   DB_PASSWORD=your_password');
    } else if (error.code === 'ER_BAD_DB_ERROR') {
      console.error('💡 Database không tồn tại. Script sẽ tự tạo database.');
    }
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
      console.log('🔌 Đã đóng kết nối.');
    }
  }
}

importDatabase();

