import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { pool, query } from './db.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Simple colorized logger (no external deps)
const COLORS = {
  reset: '\x1b[0m',
  dim: '\x1b[90m',
  cyan: '\x1b[36m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  red: '\x1b[31m',
  magenta: '\x1b[35m'
};

const logTime = () => new Date().toLocaleTimeString('vi-VN', { hour12: false });
const formatMeta = (meta) => meta ? `${COLORS.dim}${JSON.stringify(meta, null, 2)}${COLORS.reset}` : '';

const logger = {
  info(msg, meta){
    console.log(`${COLORS.cyan}[${logTime()}][INFO]${COLORS.reset} ${msg}${meta ? '\n' + formatMeta(meta) : ''}`);
  },
  success(msg, meta){
    console.log(`${COLORS.green}[${logTime()}][OK]${COLORS.reset} ${msg}${meta ? '\n' + formatMeta(meta) : ''}`);
  },
  warn(msg, meta){
    console.warn(`${COLORS.yellow}[${logTime()}][WARN]${COLORS.reset} ${msg}${meta ? '\n' + formatMeta(meta) : ''}`);
  },
  error(msg, meta){
    console.error(`${COLORS.red}[${logTime()}][ERROR]${COLORS.reset} ${msg}${meta ? '\n' + formatMeta(meta) : ''}`);
  },
  http(msg){
    console.log(`${COLORS.magenta}[${logTime()}][HTTP]${COLORS.reset} ${msg}`);
  }
};

// Load .env inside server folder
dotenv.config({ path: path.resolve(__dirname, '.env') });

const formatDate = (value) => {
  if(!value) return null;
  if(value instanceof Date){
    return value.toISOString().split('T')[0];
  }
  try{
    return new Date(value).toISOString().split('T')[0];
  }catch(e){
    return value;
  }
};

const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(cors());
app.use(express.json());

// Minimal request logger
app.use((req, res, next) => {
  logger.http(`${req.method} ${req.originalUrl || req.url}`);
  next();
});

// Serve static frontend from project root so paths remain the same
const projectRoot = path.resolve(__dirname, '..');

// Health check
app.get('/api/health', (req, res) => res.json({ ok: true }));

// --- API endpoints ---
// Register
app.post('/api/register', async (req, res) => {
  try {
    const { username, password, ten, tuoi, phone } = req.body || {};
    if(!username || !password || !ten){
      return res.status(400).json({ error: 'Thiếu thông tin bắt buộc' });
    }
    const exist = await query('SELECT account_id FROM tai_khoan WHERE username = ?', [username]);
    if(exist.length){
      return res.status(409).json({ error: 'Username đã tồn tại' });
    }
    const result = await query(
      'INSERT INTO tai_khoan (username, password, ten, tuoi, sodienthoai) VALUES (?,?,?,?,?)',
      [username, password, ten, tuoi || null, phone || null]
    );
    const account_id = result.insertId;
    // create Khach_hang row
    await query(
      'INSERT INTO Khach_hang (account_id, da_dang_ky_goi, goi_id, hlv_id, lich_tap, trang_thai_thanh_toan) VALUES (?,?,?,?,?,?)',
      [account_id, false, null, null, null, 'Chưa thanh toán']
    );
    const user = await query('SELECT account_id, username, ten, tuoi, sodienthoai FROM tai_khoan WHERE account_id = ?', [account_id]);
    res.json(user[0]);
  } catch (e) {
    logger.error('Register error', e);
    res.status(500).json({ error: 'Server error' });
  }
});

// Login (plain password for demo)
app.post('/api/login', async (req, res) => {
  try {
    const { username, password } = req.body || {};
    if(!username || !password) return res.status(400).json({ error:'Thiếu thông tin' });
    const rows = await query('SELECT account_id, username, ten, tuoi, sodienthoai FROM tai_khoan WHERE username = ? AND password = ?', [username, password]);
    if(!rows.length) return res.status(401).json({ error:'Sai thông tin đăng nhập' });
    res.json(rows[0]);
  } catch(e){
    logger.error('Login error', e);
    res.status(500).json({ error:'Server error' });
  }
});

// Packages (list + basic filter + stats)
app.get('/api/packages', async (req, res) => {
  try{
    const { q, minPrice, maxPrice } = req.query;
    const where = [];
    const params = [];
    if(q){
      where.push('ten_goi LIKE ?');
      params.push(`%${q}%`);
    }
    if(minPrice){
      where.push('gia >= ?');
      params.push(Number(minPrice));
    }
    if(maxPrice){
      where.push('gia <= ?');
      params.push(Number(maxPrice));
    }
    const whereSql = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const rows = await query(
      `
      SELECT g.goi_id, g.so_bang, g.ten_goi, g.gia, g.mo_ta, g.image,
             COUNT(k.kh_id) AS member_count
      FROM Goi_tap g
      LEFT JOIN Khach_hang k ON k.goi_id = g.goi_id AND k.da_dang_ky_goi = TRUE
      ${whereSql}
      GROUP BY g.goi_id, g.so_bang, g.ten_goi, g.gia, g.mo_ta, g.image
      ORDER BY g.so_bang ASC
      `,
      params
    );
    res.json(rows);
  }catch(e){
    logger.error('Get packages error', e);
    res.status(500).json({ error:'Server error' });
  }
});

// Payments by account
app.get('/api/payments', async (req, res) => {
  try{
    const account_id = Number(req.query.account_id);
    if(!account_id) return res.status(400).json({ error:'Thiếu account_id' });
    const rows = await query('SELECT tt_id, account_id, ten, tuoi, ten_goi, tong_tien, trang_thai, created_at FROM Thanh_toan WHERE account_id = ? ORDER BY created_at DESC', [account_id]);
    res.json(rows);
  }catch(e){
    logger.error('Get payments error', e);
    res.status(500).json({ error:'Server error' });
  }
});

// --- Admin accounts CRUD ---
app.get('/api/admin/accounts', async (req, res) => {
  try{
    const rows = await query('SELECT account_id, username, ten, tuoi, sodienthoai FROM tai_khoan ORDER BY account_id ASC');
    res.json(rows);
  }catch(e){
    logger.error('Get members error', e);
    res.status(500).json({ error:'Server error' });
  }
});

app.post('/api/admin/accounts', async (req, res) => {
  try{
    const { username, password, ten, tuoi, sodienthoai } = req.body || {};
    if(!username || !password || !ten){
      return res.status(400).json({ error:'Thiếu username, password hoặc tên' });
    }
    const exists = await query('SELECT account_id FROM tai_khoan WHERE username = ?', [username]);
    if(exists.length){
      return res.status(409).json({ error:'Username đã tồn tại' });
    }
    const result = await query(
      'INSERT INTO tai_khoan (username, password, ten, tuoi, sodienthoai) VALUES (?,?,?,?,?)',
      [username, password, ten, tuoi || null, sodienthoai || null]
    );
    const account_id = result.insertId;
    await query(
      'INSERT INTO Khach_hang (account_id, da_dang_ky_goi, goi_id, hlv_id, lich_tap, trang_thai_thanh_toan) VALUES (?,?,?,?,?,?)',
      [account_id, false, null, null, null, 'Chưa thanh toán']
    );
    const rows = await query('SELECT account_id, username, ten, tuoi, sodienthoai FROM tai_khoan WHERE account_id = ?', [account_id]);
    res.status(201).json(rows[0]);
  }catch(e){
    logger.error('Booking error', e);
    res.status(500).json({ error:'Server error' });
  }
});

app.put('/api/admin/accounts/:id', async (req, res) => {
  try{
    const id = Number(req.params.id);
    if(!id) return res.status(400).json({ error:'Thiếu account_id' });
    const { username, password, ten, tuoi, sodienthoai } = req.body || {};
    const fields = [];
    const params = [];
    if(username !== undefined){ fields.push('username = ?'); params.push(username); }
    if(password){ fields.push('password = ?'); params.push(password); }
    if(ten !== undefined){ fields.push('ten = ?'); params.push(ten); }
    if(tuoi !== undefined){ fields.push('tuoi = ?'); params.push(tuoi); }
    if(sodienthoai !== undefined){ fields.push('sodienthoai = ?'); params.push(sodienthoai); }
    if(!fields.length) return res.status(400).json({ error:'Không có gì để cập nhật' });
    params.push(id);
    await query(`UPDATE tai_khoan SET ${fields.join(', ')} WHERE account_id = ?`, params);
    const rows = await query('SELECT account_id, username, ten, tuoi, sodienthoai FROM tai_khoan WHERE account_id = ?', [id]);
    res.json(rows[0] || null);
  }catch(e){
    logger.error('Get profile error', e);
    res.status(500).json({ error:'Server error' });
  }
});

app.delete('/api/admin/accounts/:id', async (req, res) => {
  try{
    const id = Number(req.params.id);
    if(!id) return res.status(400).json({ error:'Thiếu account_id' });
    await query('DELETE FROM tai_khoan WHERE account_id = ?', [id]);
    res.json({ success:true });
  }catch(e){
    logger.error('Get HLV error', e);
    res.status(500).json({ error:'Server error' });
  }
});

// Dashboard aggregated stats
app.get('/api/admin/dashboard-stats', async (req, res) => {
  try{
    const [memberRow] = await query(`
      SELECT 
        COUNT(*) AS total,
        SUM(CASE WHEN da_dang_ky_goi = TRUE THEN 1 ELSE 0 END) AS registered
      FROM Khach_hang
    `);
    const [paymentsRow] = await query(`
      SELECT 
        COUNT(*) AS sold,
        SUM(CASE WHEN trang_thai = 'Đã thanh toán' THEN tong_tien ELSE 0 END) AS revenue,
        SUM(CASE WHEN trang_thai = 'Chưa thanh toán' THEN 1 ELSE 0 END) AS pending
      FROM Thanh_toan
    `);
    const [accountsRow] = await query('SELECT COUNT(*) AS total FROM tai_khoan');
    res.json({
      totalMembers: Number(memberRow?.total || 0),
      membersWithPackage: Number(memberRow?.registered || 0),
      packagesSold: Number(paymentsRow?.sold || 0),
      totalRevenue: Number(paymentsRow?.revenue || 0),
      pendingPayments: Number(paymentsRow?.pending || 0),
      totalAccounts: Number(accountsRow?.total || 0)
    });
  }catch(e){
    logger.error('Dashboard stats error', e);
    res.status(500).json({ error:'Server error' });
  }
});

app.get('/api/admin/dashboard-charts', async (req, res) => {
  try{
    const revenueRows = await query(`
      SELECT DATE(created_at) AS ngay, SUM(tong_tien) AS total
      FROM Thanh_toan
      WHERE trang_thai = 'Đã thanh toán'
        AND created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
      GROUP BY DATE(created_at)
      ORDER BY ngay ASC
    `);
    const growthRows = await query(`
      SELECT DATE(created_at) AS ngay, COUNT(*) AS total
      FROM Khach_hang
      WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
      GROUP BY DATE(created_at)
      ORDER BY ngay ASC
    `);
    res.json({
      revenueSeries: revenueRows.map(row => ({
        date: formatDate(row.ngay),
        total: Number(row.total) || 0
      })),
      growthSeries: growthRows.map(row => ({
        date: formatDate(row.ngay),
        total: Number(row.total) || 0
      }))
    });
  }catch(e){
    logger.error('Dashboard charts error', e);
    res.status(500).json({ error:'Server error' });
  }
});

app.get('/api/admin/payments/recent', async (req, res) => {
  try{
    const limitQuery = Number(req.query.limit) || 10;
    const limit = Math.min(Math.max(limitQuery, 1), 100);
    const rows = await query(`
      SELECT tt_id, account_id, ten, ten_goi, tong_tien, trang_thai, created_at
      FROM Thanh_toan
      ORDER BY created_at DESC
      LIMIT ${limit}
    `);
    res.json(
      rows.map(row => ({
        tt_id: row.tt_id,
        account_id: row.account_id,
        ten: row.ten,
        ten_goi: row.ten_goi,
        tong_tien: Number(row.tong_tien) || 0,
        trang_thai: row.trang_thai,
        created_at: row.created_at
      }))
    );
  }catch(e){
    logger.error('Recent payments error', e);
    res.status(500).json({ error:'Server error' });
  }
});

// Update member payment status
app.put('/api/admin/members/:accountId/payment', async (req, res) => {
  try{
    const accountId = Number(req.params.accountId);
    const { status } = req.body || {};
    if(!accountId) return res.status(400).json({ error:'Thiếu account_id' });
    if(status !== 'Đã thanh toán' && status !== 'Chưa thanh toán'){
      return res.status(400).json({ error:'Trạng thái không hợp lệ' });
    }
    await query('UPDATE Khach_hang SET trang_thai_thanh_toan = ? WHERE account_id = ?', [status, accountId]);
    await query('UPDATE Thanh_toan SET trang_thai = ? WHERE account_id = ? ORDER BY created_at DESC LIMIT 1', [status, accountId]).catch(()=>{});
    res.json({ success:true });
  }catch(e){
    logger.error('Update profile error', e);
    res.status(500).json({ error:'Server error' });
  }
});

// --- Admin login (simple, 1 fixed account) ---
// Only allow username: admin, password: 1
app.post('/api/admin-login', (req, res) => {
  try {
    const { username, password } = req.body || {};
    if (username === 'admin' && password === '1') {
      return res.json({ ok: true });
    }
    return res.status(401).json({ error: 'Sai tài khoản admin' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});

// --- HLV login: username pt{hlv_id}, password 1 ---
app.post('/api/hlv-login', async (req, res) => {
  try {
    const { username, password } = req.body || {};
    if (!username || !password) {
      return res.status(400).json({ error: 'Thiếu thông tin đăng nhập' });
    }

    if (String(password) !== '1') {
      return res.status(401).json({ error: 'Sai mật khẩu HLV (mặc định: 1)' });
    }

    // Username dạng pt1, pt2, pt3... -> map sang hlv_id
    const match = /^pt(\d+)$/.exec(String(username).toLowerCase());
    if (!match) {
      return res.status(401).json({ error: 'Tài khoản HLV không hợp lệ (dạng pt1, pt2, ...)' });
    }
    const hlvId = Number(match[1]);
    if (!hlvId) {
      return res.status(401).json({ error: 'Tài khoản HLV không hợp lệ' });
    }

    // Tra bảng HLV để đảm bảo hlv_id tồn tại
    const rows = await query(
      'SELECT hlv_id, ten_hlv, kinh_nghiem, chuyen_mon, phone, anh_url FROM HLV WHERE hlv_id = ? LIMIT 1',
      [hlvId]
    );
    if (!rows.length) {
      return res.status(401).json({ error: 'Không tìm thấy HLV tương ứng trong cơ sở dữ liệu' });
    }
    const hlv = rows[0];
    return res.json({
      hlv_id: hlv.hlv_id,
      ten_hlv: hlv.ten_hlv,
      chuyen_mon: hlv.chuyen_mon,
      phone: hlv.phone || null,
      anh_url: hlv.anh_url || null
    });
  } catch (e) {
    logger.error('HLV login error', { error: e.message });
    res.status(500).json({ error: 'Server error' });
  }
});

// Admin: members list with package & coach info
app.get('/api/members', async (req, res) => {
  try{
    const { q, status } = req.query;
    const where = [];
    const params = [];
    if(q){
      where.push('(tk.ten LIKE ? OR tk.username LIKE ? OR tk.sodienthoai LIKE ?)');
      const like = `%${q}%`;
      params.push(like, like, like);
    }
    if(status === 'active'){
      where.push('kh.da_dang_ky_goi = TRUE');
    } else if(status === 'inactive'){
      where.push('kh.da_dang_ky_goi = FALSE');
    }
    const whereSql = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const rows = await query(
      `
      SELECT
        tk.account_id,
        tk.username,
        tk.ten,
        tk.tuoi,
        tk.sodienthoai,
        kh.kh_id,
        kh.da_dang_ky_goi,
        kh.lich_tap,
        kh.ngay_bat_dau,
        kh.ngay_ket_thuc,
        kh.buoi_pt_con_lai,
        kh.trang_thai_thanh_toan,
        g.ten_goi,
        g.gia,
        h.ten_hlv,
        h.chuyen_mon
      FROM tai_khoan tk
      LEFT JOIN Khach_hang kh ON kh.account_id = tk.account_id
      LEFT JOIN Goi_tap g ON g.goi_id = kh.goi_id
      LEFT JOIN HLV h ON h.hlv_id = kh.hlv_id
      ${whereSql}
      ORDER BY tk.account_id ASC
      `,
      params
    );
    res.json(rows);
  }catch(e){
    logger.error('Create package error', e);
    res.status(500).json({ error:'Server error' });
  }
});

// Book a package
app.post('/api/book', async (req, res) => {
  try{
    const { account_id, goi_id, lich, hlv_id, pay_method, schedule_date, time_slot } = req.body || {};
    if(!account_id || !goi_id || !lich || !hlv_id || !schedule_date || !time_slot){
      return res.status(400).json({ error:'Thiếu thông tin đặt gói' });
    }
    const slotStart = (time_slot.split('-')[0] || '').trim();
    const gioBatDau = slotStart ? `${slotStart}:00`.replace('::',':') : null;
    // Update Khach_hang
    await query(
      'UPDATE Khach_hang SET da_dang_ky_goi = TRUE, goi_id = ?, hlv_id = ?, lich_tap = ?, ngay_bat_dau = ?, trang_thai_thanh_toan = ? WHERE account_id = ?',
      [goi_id, hlv_id, `${schedule_date} ${time_slot}`, schedule_date, 'Đã thanh toán', account_id]
    );
    // Save detailed schedule
    if(gioBatDau){
      await query(
        'INSERT INTO Dat_lich (account_id, hlv_id, ngay, gio_bat_dau, trang_thai) VALUES (?,?,?,?,?)',
        [account_id, hlv_id, schedule_date, gioBatDau, 'Xác nhận']
      );
    }
    // Payment record
    const pkgRows = await query('SELECT ten_goi, gia FROM Goi_tap WHERE goi_id = ?', [goi_id]);
    const userRows = await query('SELECT ten, tuoi FROM tai_khoan WHERE account_id = ?', [account_id]);
    const ten_goi = pkgRows[0]?.ten_goi || '';
    const tong_tien = pkgRows[0]?.gia || 0;
    const ten = userRows[0]?.ten || '';
    const tuoi = userRows[0]?.tuoi || null;
    await query(
      'INSERT INTO Thanh_toan (account_id, ten, tuoi, ten_goi, tong_tien, trang_thai) VALUES (?,?,?,?,?,?)',
      [account_id, ten, tuoi, ten_goi, tong_tien, 'Đã thanh toán']
    );
    res.json({ success:true });
  }catch(e){
    logger.error('Update package error', e);
    res.status(500).json({ error:'Server error' });
  }
});

// Optional: profile combined
app.get('/api/profile', async (req, res) => {
  try{
    const account_id = Number(req.query.account_id);
    if(!account_id) return res.status(400).json({ error:'Thiếu account_id' });
    const khRows = await query('SELECT * FROM Khach_hang WHERE account_id = ?', [account_id]);
    const kh = khRows[0] || null;
    let pkg = null; let hlv = null;
    if(kh?.goi_id){
      const p = await query('SELECT goi_id, so_bang, ten_goi, gia, mo_ta FROM Goi_tap WHERE goi_id = ?', [kh.goi_id]);
      pkg = p[0] || null;
    }
    if(kh?.hlv_id){
      const h = await query('SELECT hlv_id, ten_hlv, kinh_nghiem, chuyen_mon, phone, anh_url, mo_ta FROM HLV WHERE hlv_id = ?', [kh.hlv_id]);
      hlv = h[0] || null;
    }
    const payments = await query('SELECT * FROM Thanh_toan WHERE account_id = ? ORDER BY created_at DESC', [account_id]);
    const schedules = await query('SELECT dat_id, ngay, gio_bat_dau, trang_thai FROM Dat_lich WHERE account_id = ? ORDER BY ngay ASC, gio_bat_dau ASC', [account_id]);
    res.json({ kh, pkg, hlv, payments, schedules });
  }catch(e){
    logger.error('Delete package error', e);
    res.status(500).json({ error:'Server error' });
  }
});

// Get HLV list
app.get('/api/hlv', async (req, res) => {
  try{
    const rows = await query('SELECT hlv_id, ten_hlv, kinh_nghiem, chuyen_mon, phone, anh_url, mo_ta FROM HLV ORDER BY hlv_id ASC');
    res.json(rows);
  }catch(e){
    console.error(e);
    res.status(500).json({ error:'Server error' });
  }
});

// Get single HLV by id (for HLV portal header)
app.get('/api/hlv/:id', async (req, res) => {
  try{
    const id = Number(req.params.id);
    if(!id) return res.status(400).json({ error:'Thiếu hlv_id hợp lệ' });
    const rows = await query('SELECT hlv_id, ten_hlv, kinh_nghiem, chuyen_mon, phone, anh_url, mo_ta FROM HLV WHERE hlv_id = ?', [id]);
    if(!rows.length) return res.status(404).json({ error:'Không tìm thấy HLV' });
    res.json(rows[0]);
  }catch(e){
    console.error('Get HLV by id error', e);
    res.status(500).json({ error:'Server error' });
  }
});

// Admin HLV CRUD
app.get('/api/admin/hlv', async (req, res) => {
  try{
    const rows = await query('SELECT hlv_id, ten_hlv, kinh_nghiem, chuyen_mon, phone, anh_url, mo_ta FROM HLV ORDER BY hlv_id ASC');
    res.json(rows);
  }catch(e){
    logger.error('Get HLV list error', e);
    res.status(500).json({ error:'Server error' });
  }
});

app.post('/api/admin/hlv', async (req, res) => {
  try{
    const { ten_hlv, kinh_nghiem, chuyen_mon, phone, anh_url, mo_ta } = req.body || {};
    if(!ten_hlv){
      return res.status(400).json({ error:'Tên HLV là bắt buộc' });
    }
    const result = await query(
      'INSERT INTO HLV (ten_hlv, kinh_nghiem, chuyen_mon, phone, anh_url, mo_ta) VALUES (?,?,?,?,?,?)',
      [ten_hlv, kinh_nghiem || null, chuyen_mon || null, phone || null, anh_url || null, mo_ta || null]
    );
    const rows = await query('SELECT hlv_id, ten_hlv, kinh_nghiem, chuyen_mon, phone, anh_url, mo_ta FROM HLV WHERE hlv_id = ?', [result.insertId]);
    res.status(201).json(rows[0]);
  }catch(e){
    logger.error('Create HLV error', e);
    res.status(500).json({ error:'Server error' });
  }
});

app.put('/api/admin/hlv/:id', async (req, res) => {
  try{
    const id = Number(req.params.id);
    if(!id) return res.status(400).json({ error:'Thiếu hlv_id' });
    const { ten_hlv, kinh_nghiem, chuyen_mon, phone, anh_url, mo_ta } = req.body || {};
    const fields = [];
    const params = [];
    if(ten_hlv !== undefined){ fields.push('ten_hlv = ?'); params.push(ten_hlv); }
    if(kinh_nghiem !== undefined){ fields.push('kinh_nghiem = ?'); params.push(kinh_nghiem); }
    if(chuyen_mon !== undefined){ fields.push('chuyen_mon = ?'); params.push(chuyen_mon); }
    if(phone !== undefined){ fields.push('phone = ?'); params.push(phone); }
    if(anh_url !== undefined){ fields.push('anh_url = ?'); params.push(anh_url); }
    if(mo_ta !== undefined){ fields.push('mo_ta = ?'); params.push(mo_ta); }
    if(!fields.length) return res.status(400).json({ error:'Không có gì để cập nhật' });
    params.push(id);
    await query(`UPDATE HLV SET ${fields.join(', ')} WHERE hlv_id = ?`, params);
    const rows = await query('SELECT hlv_id, ten_hlv, kinh_nghiem, chuyen_mon, phone, anh_url, mo_ta FROM HLV WHERE hlv_id = ?', [id]);
    res.json(rows[0] || null);
  }catch(e){
    logger.error('Update HLV error', e);
    res.status(500).json({ error:'Server error' });
  }
});

app.delete('/api/admin/hlv/:id', async (req, res) => {
  try{
    const id = Number(req.params.id);
    if(!id) return res.status(400).json({ error:'Thiếu hlv_id' });
    await query('DELETE FROM HLV WHERE hlv_id = ?', [id]);
    res.json({ success:true });
  }catch(e){
    logger.error('Delete HLV error', e);
    res.status(500).json({ error:'Server error' });
  }
});

// Update profile (ten, tuoi, password)
app.put('/api/profile', async (req, res) => {
  try{
    const { account_id, ten, tuoi, password } = req.body || {};
    if(!account_id) return res.status(400).json({ error:'Thiếu account_id' });
    const fields = [];
    const params = [];
    if(ten !== undefined){ fields.push('ten = ?'); params.push(ten); }
    if(tuoi !== undefined){ fields.push('tuoi = ?'); params.push(tuoi); }
    if(password){ fields.push('password = ?'); params.push(password); }
    if(!fields.length) return res.status(400).json({ error:'Không có gì để cập nhật' });
    params.push(account_id);
    await query(`UPDATE tai_khoan SET ${fields.join(', ')} WHERE account_id = ?`, params);
    const rows = await query('SELECT account_id, username, ten, tuoi, sodienthoai FROM tai_khoan WHERE account_id = ?', [account_id]);
    res.json(rows[0]);
  }catch(e){
    console.error(e);
    res.status(500).json({ error:'Server error' });
  }
});

// Manage packages (add/update/delete)
app.post('/api/packages', async (req, res) => {
  try{
    const { so_bang, ten_goi, gia, mo_ta, image } = req.body || {};
    if(!ten_goi || gia === undefined) return res.status(400).json({ error:'Thiếu tên gói hoặc giá' });
    const result = await query(
      'INSERT INTO Goi_tap (so_bang, ten_goi, gia, mo_ta, image) VALUES (?,?,?,?,?)',
      [so_bang || null, ten_goi, gia, mo_ta || null, image || null]
    );
    const row = await query(
      'SELECT goi_id, so_bang, ten_goi, gia, mo_ta, image FROM Goi_tap WHERE goi_id = ?',
      [result.insertId]
    );
    res.status(201).json(row[0]);
  }catch(e){
    console.error(e);
    res.status(500).json({ error:'Server error' });
  }
});

app.put('/api/packages/:id', async (req, res) => {
  try{
    const id = Number(req.params.id);
    if(!id) return res.status(400).json({ error:'Thiếu id' });
    const { so_bang, ten_goi, gia, mo_ta, image } = req.body || {};
    const fields = [];
    const params = [];
    if(so_bang !== undefined){ fields.push('so_bang = ?'); params.push(so_bang); }
    if(ten_goi !== undefined){ fields.push('ten_goi = ?'); params.push(ten_goi); }
    if(gia !== undefined){ fields.push('gia = ?'); params.push(gia); }
    if(mo_ta !== undefined){ fields.push('mo_ta = ?'); params.push(mo_ta); }
    if(image !== undefined){ fields.push('image = ?'); params.push(image); }
    if(!fields.length) return res.status(400).json({ error:'Không có gì để cập nhật' });
    params.push(id);
    await query(`UPDATE Goi_tap SET ${fields.join(', ')} WHERE goi_id = ?`, params);
    const rows = await query('SELECT goi_id, so_bang, ten_goi, gia, mo_ta, image FROM Goi_tap WHERE goi_id = ?', [id]);
    res.json(rows[0] || null);
  }catch(e){
    console.error(e);
    res.status(500).json({ error:'Server error' });
  }
});

app.delete('/api/packages/:id', async (req, res) => {
  try{
    const id = Number(req.params.id);
    if(!id) return res.status(400).json({ error:'Thiếu id' });
    await query('DELETE FROM Goi_tap WHERE goi_id = ?', [id]);
    res.json({ success:true });
  }catch(e){
    console.error(e);
    res.status(500).json({ error:'Server error' });
  }
});

// Settings API
app.get('/api/settings', async (req, res) => {
  try{
    const rows = await query('SELECT setting_key, setting_value, setting_type FROM system_settings');
    const settings = {};
    rows.forEach(row => {
      if(row.setting_type === 'json'){
        try{
          settings[row.setting_key] = JSON.parse(row.setting_value || '{}');
        }catch(e){
          settings[row.setting_key] = row.setting_value;
        }
      }else{
        settings[row.setting_key] = row.setting_value || '';
      }
    });
    res.json(settings);
  }catch(e){
    console.error(e);
    res.status(500).json({ error:'Server error' });
  }
});

app.put('/api/settings', async (req, res) => {
  try{
    const updates = req.body || {};
    if(!updates || Object.keys(updates).length === 0){
      return res.status(400).json({ error:'Không có dữ liệu để cập nhật' });
    }
    
    for(const [key, value] of Object.entries(updates)){
      const settingType = typeof value === 'object' ? 'json' : 'text';
      let settingValue;
      try{
        settingValue = settingType === 'json' ? JSON.stringify(value) : String(value);
      }catch(e){
        logger.error('Error stringifying setting value', { key, error: e.message });
        settingValue = String(value);
      }
      
      try{
        await query(
          'INSERT INTO system_settings (setting_key, setting_value, setting_type) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE setting_value = ?, setting_type = ?',
          [key, settingValue, settingType, settingValue, settingType]
        );
      }catch(dbError){
        logger.error('Database error updating setting', { key, error: dbError.message });
        // If table doesn't exist, try to create it
        if(dbError.code === 'ER_NO_SUCH_TABLE'){
          logger.warn('system_settings table not found, attempting to create...');
          try{
            await query(`
              CREATE TABLE IF NOT EXISTS system_settings (
                setting_id INT AUTO_INCREMENT PRIMARY KEY,
                setting_key VARCHAR(100) NOT NULL UNIQUE,
                setting_value TEXT,
                setting_type VARCHAR(50) DEFAULT 'text',
                description TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            `);
            // Retry the insert
            await query(
              'INSERT INTO system_settings (setting_key, setting_value, setting_type) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE setting_value = ?, setting_type = ?',
              [key, settingValue, settingType, settingValue, settingType]
            );
          }catch(createError){
            logger.error('Failed to create system_settings table', { error: createError.message });
            return res.status(500).json({ error:'Database error: ' + createError.message });
          }
        }else{
          throw dbError;
        }
      }
    }
    res.json({ success:true, message:'Đã lưu cài đặt thành công' });
  }catch(e){
    logger.error('Error in PUT /api/settings', { error: e.message, stack: e.stack });
    res.status(500).json({ error:'Server error: ' + e.message });
  }
});

// Schedules API
app.get('/api/admin/schedules', async (req, res) => {
  try{
    const { date, status, hlv_id } = req.query || {};
    let sql = `
      SELECT 
        d.dat_id,
        d.account_id,
        d.hlv_id,
        d.ngay,
        d.gio_bat_dau,
        d.trang_thai,
        d.created_at,
        t.ten as member_name,
        t.sodienthoai as member_phone,
        h.ten_hlv,
        h.phone as hlv_phone
      FROM Dat_lich d
      LEFT JOIN tai_khoan t ON d.account_id = t.account_id
      LEFT JOIN HLV h ON d.hlv_id = h.hlv_id
      WHERE 1=1
    `;
    const params = [];
    if(date){
      sql += ' AND d.ngay = ?';
      params.push(date);
    }
    if(status){
      sql += ' AND d.trang_thai = ?';
      params.push(status);
    }
    if(hlv_id){
      sql += ' AND d.hlv_id = ?';
      params.push(Number(hlv_id));
    }
    sql += ' ORDER BY d.ngay ASC, d.gio_bat_dau ASC';
    const rows = await query(sql, params);
    res.json(rows);
  }catch(e){
    console.error(e);
    res.status(500).json({ error:'Server error' });
  }
});

app.put('/api/admin/schedules/:id', async (req, res) => {
  try{
    const id = Number(req.params.id);
    if(!id) return res.status(400).json({ error:'Thiếu id' });
    const { trang_thai, ngay, gio_bat_dau, hlv_id } = req.body || {};
    const fields = [];
    const params = [];
    if(trang_thai !== undefined){ fields.push('trang_thai = ?'); params.push(trang_thai); }
    if(ngay !== undefined){ fields.push('ngay = ?'); params.push(ngay); }
    if(gio_bat_dau !== undefined){ fields.push('gio_bat_dau = ?'); params.push(gio_bat_dau); }
    if(hlv_id !== undefined){ fields.push('hlv_id = ?'); params.push(Number(hlv_id)); }
    if(!fields.length) return res.status(400).json({ error:'Không có gì để cập nhật' });
    params.push(id);
    await query(`UPDATE Dat_lich SET ${fields.join(', ')} WHERE dat_id = ?`, params);
    const rows = await query(`
      SELECT 
        d.dat_id,
        d.account_id,
        d.hlv_id,
        d.ngay,
        d.gio_bat_dau,
        d.trang_thai,
        t.ten as member_name,
        h.ten_hlv
      FROM Dat_lich d
      LEFT JOIN tai_khoan t ON d.account_id = t.account_id
      LEFT JOIN HLV h ON d.hlv_id = h.hlv_id
      WHERE d.dat_id = ?
    `, [id]);
    res.json(rows[0] || null);
  }catch(e){
    console.error(e);
    res.status(500).json({ error:'Server error' });
  }
});

app.delete('/api/admin/schedules/:id', async (req, res) => {
  try{
    const id = Number(req.params.id);
    if(!id) return res.status(400).json({ error:'Thiếu id' });
    await query('DELETE FROM Dat_lich WHERE dat_id = ?', [id]);
    res.json({ success:true });
  }catch(e){
    console.error(e);
    res.status(500).json({ error:'Server error' });
  }
});

// Static assets & SPA fallback
app.use(express.static(projectRoot));
app.get('*', (req, res) => {
  res.sendFile(path.join(projectRoot, 'index.html'));
});

app.listen(PORT, () => {
  logger.success(`API & static server đang chạy tại http://localhost:${PORT}`);
});
