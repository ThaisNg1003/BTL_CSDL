import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config({ path: path.resolve(__dirname, '.env') });

const config = {
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'Thai1003@',
  database: process.env.DB_NAME || 'gym_management',
  multipleStatements: true,
  charset: 'utf8mb4_general_ci'
};

export const pool = mysql.createPool(config);

export async function query(sql, params = []){
  const [result, fields] = await pool.execute(sql, params);
  // For INSERT/UPDATE/DELETE, result is ResultSetHeader with insertId/affectedRows
  // For SELECT, result is array of rows
  if(sql.trim().toUpperCase().startsWith('INSERT')){
    return { insertId: result.insertId, affectedRows: result.affectedRows };
  }
  return result;
}
