Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  SETUP DATABASE - M1-GYM" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

Write-Host "[1/3] Kiểm tra MySQL..." -ForegroundColor Yellow
$mysqlPath = Get-Command mysql -ErrorAction SilentlyContinue
if (-not $mysqlPath) {
    Write-Host "❌ MySQL không được tìm thấy trong PATH" -ForegroundColor Red
    Write-Host "💡 Vui lòng cài đặt MySQL hoặc thêm MySQL vào PATH" -ForegroundColor Yellow
    Write-Host "💡 Hoặc sử dụng MySQL Workbench/phpMyAdmin để import file gym_management.sql" -ForegroundColor Yellow
    Read-Host "Nhấn Enter để thoát"
    exit 1
}

Write-Host "✅ MySQL đã được tìm thấy" -ForegroundColor Green
Write-Host ""

Write-Host "[2/3] Tạo file .env..." -ForegroundColor Yellow
if (-not (Test-Path "server\.env")) {
    if (Test-Path "server\.env.example") {
        Copy-Item "server\.env.example" "server\.env"
        Write-Host "✅ Đã tạo file server\.env" -ForegroundColor Green
        Write-Host "⚠️  Vui lòng chỉnh sửa server\.env với thông tin MySQL của bạn" -ForegroundColor Yellow
    } else {
        Write-Host "⚠️  Không tìm thấy .env.example. Vui lòng tạo file .env thủ công." -ForegroundColor Yellow
    }
} else {
    Write-Host "✅ File server\.env đã tồn tại" -ForegroundColor Green
}
Write-Host ""

Write-Host "[3/3] Import database..." -ForegroundColor Yellow
Set-Location server
npm run import-db
Set-Location ..

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
if ($LASTEXITCODE -eq 0) {
    Write-Host "✅ SETUP HOÀN TẤT!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Bạn có thể chạy server bằng: npm start" -ForegroundColor Cyan
} else {
    Write-Host "❌ CÓ LỖI XẢY RA" -ForegroundColor Red
    Write-Host ""
    Write-Host "Cách import thủ công:" -ForegroundColor Yellow
    Write-Host "1. Mở MySQL Workbench hoặc phpMyAdmin"
    Write-Host "2. Tạo database tên: gym_management"
    Write-Host "3. Import file: gym_management.sql"
}
Write-Host "========================================" -ForegroundColor Cyan
Read-Host "Nhấn Enter để thoát"

