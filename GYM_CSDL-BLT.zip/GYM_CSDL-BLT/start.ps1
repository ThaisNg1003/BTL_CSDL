Set-Location server
npm start
