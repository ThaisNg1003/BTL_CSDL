import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { pool, query } from './db.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load .env inside server folder
dotenv.config({ path: path.resolve(__dirname, '.env') });

const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(cors());
app.use(express.json());

// Serve static frontend from project root so paths remain the same
const projectRoot = path.resolve(__dirname, '..');
app.use(express.static(projectRoot));

// Health check
app.get('/api/health', (req, res) => res.json({ ok: true }));

// --- API endpoints ---
// Register
app.post('/api/register', async (req, res) => {
  try {
    const { username, password, ten, tuoi, phone } = req.body || {};
    if(!username || !password || !ten){
      return res.status(400).json({ error: 'Thiếu thông tin bắt buộc' });
    }
    const exist = await query('SELECT account_id FROM tai_khoan WHERE username = ?', [username]);
    if(exist.length){
      return res.status(409).json({ error: 'Username đã tồn tại' });
    }
    const result = await query(
      'INSERT INTO tai_khoan (username, password, ten, tuoi, sodienthoai) VALUES (?,?,?,?,?)',
      [username, password, ten, tuoi || null, phone || null]
    );
    const account_id = result.insertId;
    // create Khach_hang row
    await query(
      'INSERT INTO Khach_hang (account_id, da_dang_ky_goi, goi_id, hlv_id, lich_tap, trang_thai_thanh_toan) VALUES (?,?,?,?,?,?)',
      [account_id, false, null, null, null, 'Chưa thanh toán']
    );
    const user = await query('SELECT account_id, username, ten, tuoi, sodienthoai FROM tai_khoan WHERE account_id = ?', [account_id]);
    res.json(user[0]);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});

// Login (plain password for demo)
app.post('/api/login', async (req, res) => {
  try {
    const { username, password } = req.body || {};
    if(!username || !password) return res.status(400).json({ error:'Thiếu thông tin' });
    const rows = await query('SELECT account_id, username, ten, tuoi, sodienthoai FROM tai_khoan WHERE username = ? AND password = ?', [username, password]);
    if(!rows.length) return res.status(401).json({ error:'Sai thông tin đăng nhập' });
    res.json(rows[0]);
  } catch(e){
    console.error(e);
    res.status(500).json({ error:'Server error' });
  }
});

// Packages
app.get('/api/packages', async (req, res) => {
  try{
    const rows = await query('SELECT goi_id, so_bang, ten_goi, gia, mo_ta FROM Goi_tap ORDER BY so_bang ASC');
    res.json(rows);
  }catch(e){
    console.error(e);
    res.status(500).json({ error:'Server error' });
  }
});

// Payments by account
app.get('/api/payments', async (req, res) => {
  try{
    const account_id = Number(req.query.account_id);
    if(!account_id) return res.status(400).json({ error:'Thiếu account_id' });
    const rows = await query('SELECT tt_id, account_id, ten, tuoi, ten_goi, tong_tien, trang_thai, created_at FROM Thanh_toan WHERE account_id = ? ORDER BY created_at DESC', [account_id]);
    res.json(rows);
  }catch(e){
    console.error(e);
    res.status(500).json({ error:'Server error' });
  }
});

// Book a package
app.post('/api/book', async (req, res) => {
  try{
    const { account_id, goi_id, lich, hlv_id, pay_method } = req.body || {};
    if(!account_id || !goi_id || !lich || !hlv_id){
      return res.status(400).json({ error:'Thiếu thông tin đặt gói' });
    }
    // Update Khach_hang
    await query(
      'UPDATE Khach_hang SET da_dang_ky_goi = TRUE, goi_id = ?, hlv_id = ?, lich_tap = ?, trang_thai_thanh_toan = ? WHERE account_id = ?',
      [goi_id, hlv_id, lich, 'Đã thanh toán', account_id]
    );
    // Payment record
    const pkgRows = await query('SELECT ten_goi, gia FROM Goi_tap WHERE goi_id = ?', [goi_id]);
    const userRows = await query('SELECT ten, tuoi FROM tai_khoan WHERE account_id = ?', [account_id]);
    const ten_goi = pkgRows[0]?.ten_goi || '';
    const tong_tien = pkgRows[0]?.gia || 0;
    const ten = userRows[0]?.ten || '';
    const tuoi = userRows[0]?.tuoi || null;
    await query(
      'INSERT INTO Thanh_toan (account_id, ten, tuoi, ten_goi, tong_tien, trang_thai) VALUES (?,?,?,?,?,?)',
      [account_id, ten, tuoi, ten_goi, tong_tien, 'Đã thanh toán']
    );
    res.json({ success:true });
  }catch(e){
    console.error(e);
    res.status(500).json({ error:'Server error' });
  }
});

// Optional: profile combined
app.get('/api/profile', async (req, res) => {
  try{
    const account_id = Number(req.query.account_id);
    if(!account_id) return res.status(400).json({ error:'Thiếu account_id' });
    const khRows = await query('SELECT * FROM Khach_hang WHERE account_id = ?', [account_id]);
    const kh = khRows[0] || null;
    let pkg = null; let hlv = null;
    if(kh?.goi_id){
      const p = await query('SELECT goi_id, so_bang, ten_goi, gia, mo_ta FROM Goi_tap WHERE goi_id = ?', [kh.goi_id]);
      pkg = p[0] || null;
    }
    if(kh?.hlv_id){
      const h = await query('SELECT hlv_id, ten_hlv, kinh_nghiem, chuyen_mon, phone, anh_url, mo_ta FROM HLV WHERE hlv_id = ?', [kh.hlv_id]);
      hlv = h[0] || null;
    }
    const payments = await query('SELECT * FROM Thanh_toan WHERE account_id = ? ORDER BY created_at DESC', [account_id]);
    res.json({ kh, pkg, hlv, payments });
  }catch(e){
    console.error(e);
    res.status(500).json({ error:'Server error' });
  }
});

// Get HLV list
app.get('/api/hlv', async (req, res) => {
  try{
    const rows = await query('SELECT hlv_id, ten_hlv, kinh_nghiem, chuyen_mon, phone, anh_url, mo_ta FROM HLV ORDER BY hlv_id ASC');
    res.json(rows);
  }catch(e){
    console.error(e);
    res.status(500).json({ error:'Server error' });
  }
});

// Update profile (ten, tuoi, password)
app.put('/api/profile', async (req, res) => {
  try{
    const { account_id, ten, tuoi, password } = req.body || {};
    if(!account_id) return res.status(400).json({ error:'Thiếu account_id' });
    const fields = [];
    const params = [];
    if(ten !== undefined){ fields.push('ten = ?'); params.push(ten); }
    if(tuoi !== undefined){ fields.push('tuoi = ?'); params.push(tuoi); }
    if(password){ fields.push('password = ?'); params.push(password); }
    if(!fields.length) return res.status(400).json({ error:'Không có gì để cập nhật' });
    params.push(account_id);
    await query(`UPDATE tai_khoan SET ${fields.join(', ')} WHERE account_id = ?`, params);
    const rows = await query('SELECT account_id, username, ten, tuoi, sodienthoai FROM tai_khoan WHERE account_id = ?', [account_id]);
    res.json(rows[0]);
  }catch(e){
    console.error(e);
    res.status(500).json({ error:'Server error' });
  }
});

// Manage packages (add/delete)
app.post('/api/packages', async (req, res) => {
  try{
    const { so_bang, ten_goi, gia, mo_ta } = req.body || {};
    if(!ten_goi || gia === undefined) return res.status(400).json({ error:'Thiếu tên gói hoặc giá' });
    const result = await query('INSERT INTO Goi_tap (so_bang, ten_goi, gia, mo_ta) VALUES (?,?,?,?)', [so_bang || null, ten_goi, gia, mo_ta || null]);
    const row = await query('SELECT goi_id, so_bang, ten_goi, gia, mo_ta FROM Goi_tap WHERE goi_id = ?', [result.insertId]);
    res.status(201).json(row[0]);
  }catch(e){
    console.error(e);
    res.status(500).json({ error:'Server error' });
  }
});

app.delete('/api/packages/:id', async (req, res) => {
  try{
    const id = Number(req.params.id);
    if(!id) return res.status(400).json({ error:'Thiếu id' });
    await query('DELETE FROM Goi_tap WHERE goi_id = ?', [id]);
    res.json({ success:true });
  }catch(e){
    console.error(e);
    res.status(500).json({ error:'Server error' });
  }
});

// Fallback to index.html for root
app.get('*', (req, res) => {
  res.sendFile(path.join(projectRoot, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`API & static server running on http://localhost:${PORT}`);
});
