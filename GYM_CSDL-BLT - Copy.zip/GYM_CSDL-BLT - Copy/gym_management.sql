-- Gym N12 database schema
-- Run: mysql -u root -p < gym_management.sql

CREATE DATABASE IF NOT EXISTS gym_n12;
USE gym_n12;

-- Table: tai_khoan (accounts / users)
CREATE TABLE IF NOT EXISTS tai_khoan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(80) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  ten VARCHAR(150) NOT NULL,
  tuoi INT DEFAULT NULL,
  sodienthoai VARCHAR(30) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: goi_tap (packages)
CREATE TABLE IF NOT EXISTS goi_tap (
  id INT AUTO_INCREMENT PRIMARY KEY,
  so_bang INT DEFAULT NULL,
  ten_goi VARCHAR(200) NOT NULL,
  gia DECIMAL(12,2) NOT NULL DEFAULT 0,
  mo_ta TEXT,
  image VARCHAR(255) DEFAULT NULL,
  active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: hlv (coaches)
CREATE TABLE IF NOT EXISTS hlv (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ten VARCHAR(150) NOT NULL,
  anh_url VARCHAR(255) DEFAULT NULL,
  chuyen_mon VARCHAR(150) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: khach_hang (customer profile linked to tai_khoan)
CREATE TABLE IF NOT EXISTS khach_hang (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tai_khoan_id INT NOT NULL,
  da_dang_ky_goi TINYINT(1) DEFAULT 0,
  goi_id INT DEFAULT NULL,
  hlv_id INT DEFAULT NULL,
  lich_tap ENUM('SÁNG (8-11)','CHIỀU (15-18)','TỐI (19-22)') DEFAULT NULL,
  trang_thai_thanh_toan ENUM('Chưa thanh toán','Đã thanh toán') DEFAULT 'Chưa thanh toán',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (tai_khoan_id) REFERENCES tai_khoan(id) ON DELETE CASCADE,
  FOREIGN KEY (goi_id) REFERENCES goi_tap(id) ON DELETE SET NULL,
  FOREIGN KEY (hlv_id) REFERENCES hlv(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table: thanh_toan (payments)
CREATE TABLE IF NOT EXISTS thanh_toan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tai_khoan_id INT NOT NULL,
  ho_ten VARCHAR(150) DEFAULT NULL,
  tuoi INT DEFAULT NULL,
  goi_id INT DEFAULT NULL,
  tong_tien DECIMAL(12,2) DEFAULT 0,
  trang_thai ENUM('Chưa thanh toán','Đã thanh toán') DEFAULT 'Chưa thanh toán',
  qr_image VARCHAR(255) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (tai_khoan_id) REFERENCES tai_khoan(id) ON DELETE CASCADE,
  FOREIGN KEY (goi_id) REFERENCES goi_tap(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Optional attendance table (attendance / logs)
CREATE TABLE IF NOT EXISTS attendance (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tai_khoan_id INT NOT NULL,
  checkin_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  note VARCHAR(255) DEFAULT NULL,
  FOREIGN KEY (tai_khoan_id) REFERENCES tai_khoan(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed data: accounts (tk1, tk2, tk3) per requirement
INSERT INTO tai_khoan (username, password, ten, tuoi, sodienthoai)
VALUES
  ('tk1', '1', 'Người dùng 1', 20, '0901000001'),
  ('tk2', '1', 'Người dùng 2', 22, '0901000002'),
  ('tk3', '2', 'Người dùng 3', 25, '0901000003')
ON DUPLICATE KEY UPDATE username=VALUES(username);

-- Seed data: packages (8 packages)
INSERT INTO goi_tap (so_bang, ten_goi, gia, mo_ta, image)
VALUES
  (1, 'Gói 1 tháng - Cơ bản', 300000.00, 'Gói tập không giới hạn trong 1 tháng - dành cho người mới', '/images/package-1.svg'),
  (2, 'Gói 1 tháng - Nâng cao', 400000.00, 'Gói 1 tháng với 2 buổi HLV', '/images/package-2.svg'),
  (3, 'Gói 3 tháng - Tiết kiệm', 800000.00, 'Gói 3 tháng - tiết kiệm', '/images/package-3.svg'),
  (4, 'Gói 6 tháng - Bạc', 1500000.00, 'Gói 6 tháng - ưu đãi', '/images/package-4.svg'),
  (5, 'Gói 12 tháng - Vàng', 2800000.00, 'Gói 12 tháng', '/images/package-5.svg'),
  (6, 'Gói Sinh Viên 6 tháng', 1000000.00, 'Giảm giá cho sinh viên', '/images/package-6.svg'),
  (7, 'Gói Tăng cơ 3 tháng', 900000.00, 'Tập trung tăng cơ, kèm HLV', '/images/package-7.svg'),
  (8, 'Gói Yoga 1 tháng', 350000.00, 'Gói yoga 1 tháng', '/images/package-8.svg')
ON DUPLICATE KEY UPDATE ten_goi=VALUES(ten_goi);

-- Seed data: HLV (3 coaches)
INSERT INTO hlv (ten, anh_url, chuyen_mon)
VALUES
  ('Nguyễn Văn A', '/images/hlv-1.svg', 'Tăng cơ'),
  ('Trần Thị B', '/images/hlv-2.svg', 'Yoga'),
  ('Lê Văn C', '/images/hlv-3.svg', 'Cardio')
ON DUPLICATE KEY UPDATE ten=VALUES(ten);

-- Create sample customer profiles linking to accounts
INSERT INTO khach_hang (tai_khoan_id, da_dang_ky_goi, goi_id, hlv_id, lich_tap, trang_thai_thanh_toan)
VALUES
  (1, 1, 3, 1, 'SÁNG (8-11)', 'Đã thanh toán'),
  (2, 0, NULL, NULL, NULL, 'Chưa thanh toán'),
  (3, 0, NULL, NULL, NULL, 'Chưa thanh toán')
ON DUPLICATE KEY UPDATE tai_khoan_id=VALUES(tai_khoan_id);

-- Sample payment record
INSERT INTO thanh_toan (tai_khoan_id, ho_ten, tuoi, goi_id, tong_tien, trang_thai, qr_image)
VALUES
  (1, 'Người dùng 1', 20, 3, 800000.00, 'Đã thanh toán', NULL)
ON DUPLICATE KEY UPDATE tai_khoan_id=VALUES(tai_khoan_id);

COMMIT;
-- gym_management.sql
-- Database và các bảng theo đặc tả (tên tiếng Việt)

CREATE DATABASE IF NOT EXISTS gym_management CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE gym_management;

-- bảng tài khoản (tai_khoan)
CREATE TABLE IF NOT EXISTS tai_khoan (
    account_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,    -- tài khoản (duy nhất)
    password VARCHAR(255) NOT NULL,            -- mật khẩu (lưu hashed khi backend có)
    ten VARCHAR(150) NOT NULL,                 -- tên
    tuoi INT CHECK (tuoi >= 10 AND tuoi <= 120),
    sodienthoai VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- bảng gói tập (Goi_tap)
CREATE TABLE IF NOT EXISTS Goi_tap (
    goi_id INT AUTO_INCREMENT PRIMARY KEY,
    so_bang INT, -- số bảng (bạn đề cập "Số bảng" — giữ trường này)
    ten_goi VARCHAR(150) NOT NULL,
    gia DECIMAL(12,2) NOT NULL,
    mo_ta TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- bảng huấn luyện viên (HLV)
CREATE TABLE IF NOT EXISTS HLV (
    hlv_id INT AUTO_INCREMENT PRIMARY KEY,
    ten_hlv VARCHAR(150) NOT NULL,
    kinh_nghiem INT,
    chuyen_mon VARCHAR(150),
    phone VARCHAR(20),
    anh_url VARCHAR(255), -- ô để gắn ảnh HLV (url hoặc path)
    mo_ta TEXT
);

-- bảng khách hàng (Khach_hang) — trạng thái, gói đã đăng ký, hlv đi kèm, lịch, trạng thái thanh toán
CREATE TABLE IF NOT EXISTS Khach_hang (
    kh_id INT AUTO_INCREMENT PRIMARY KEY,
    account_id INT NOT NULL,
    da_dang_ky_goi BOOLEAN DEFAULT FALSE, -- trạng thái đăng kí gói
    goi_id INT, -- gói đã đăng kí
    hlv_id INT,  -- HLV đi kèm
    lich_tap VARCHAR(50), -- SÁNG(8-11)/CHIỀU(15-18)/TỐI(19-22) hoặc cụ thể
    trang_thai_thanh_toan ENUM('Chưa thanh toán','Đã thanh toán') DEFAULT 'Chưa thanh toán',
    FOREIGN KEY (account_id) REFERENCES tai_khoan(account_id) ON DELETE CASCADE,
    FOREIGN KEY (goi_id) REFERENCES Goi_tap(goi_id) ON DELETE SET NULL,
    FOREIGN KEY (hlv_id) REFERENCES HLV(hlv_id) ON DELETE SET NULL
);

-- bảng thanh toán (Thanh_toan)
CREATE TABLE IF NOT EXISTS Thanh_toan (
    tt_id INT AUTO_INCREMENT PRIMARY KEY,
    account_id INT NOT NULL,
    ten VARCHAR(150),
    tuoi INT,
    ten_goi VARCHAR(150),
    tong_tien DECIMAL(12,2),
    trang_thai ENUM('Chưa thanh toán','Đã thanh toán') DEFAULT 'Chưa thanh toán',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (account_id) REFERENCES tai_khoan(account_id) ON DELETE CASCADE
);

-- bảng bookings (lịch đặt huấn luyện viên chi tiết)
CREATE TABLE IF NOT EXISTS Dat_lich (
    dat_id INT AUTO_INCREMENT PRIMARY KEY,
    account_id INT NOT NULL,
    hlv_id INT NOT NULL,
    ngay DATE,
    gio_bat_dau TIME,
    trang_thai ENUM('Đang chờ','Xác nhận','Hủy') DEFAULT 'Đang chờ',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (account_id) REFERENCES tai_khoan(account_id) ON DELETE CASCADE,
    FOREIGN KEY (hlv_id) REFERENCES HLV(hlv_id) ON DELETE CASCADE
);

-- Dữ liệu mẫu: 8 gói
INSERT INTO Goi_tap (so_bang, ten_goi, gia, mo_ta)
VALUES
(1, 'Gói 1 tháng - Cơ bản', 300000.00, 'Gói tập không giới hạn trong 1 tháng - dành cho người mới'),
(2, 'Gói 1 tháng - Nâng cao', 400000.00, 'Gói tập 1 tháng với 2 buổi HLV'),
(3, 'Gói 3 tháng - Tiết kiệm', 800000.00, 'Gói 3 tháng - tiết kiệm'),
(4, 'Gói 6 tháng - Bạc', 1500000.00, 'Gói 6 tháng - ưu đãi'),
(5, 'Gói 12 tháng - Vàng', 2800000.00, 'Gói 12 tháng - ưu đãi lớn'),
(6, 'Gói Sinh Viên 6 tháng', 1000000.00, 'Giảm giá cho sinh viên'),
(7, 'Gói Tăng cơ 3 tháng', 900000.00, 'Tập trung tăng cơ, kèm HLV'),
(8, 'Gói Yoga 1 tháng', 350000.00, 'Gói yoga & phục hồi');

-- Dữ liệu mẫu: 3 HLV
INSERT INTO HLV (ten_hlv, kinh_nghiem, chuyen_mon, phone, anh_url, mo_ta)
VALUES
('Nguyễn Văn A', 5, 'Tăng cơ - Sức mạnh', '0905123456', '', 'HLV chuyên tăng cơ'),
('Trần Thị B', 4, 'Yoga - Giảm cân', '0912345678', '', 'HLV chuyên yoga'),
('Lê Văn C', 6, 'Cardio - Thể lực', '0987654321', '', 'HLV chuyên cardio');

-- Dữ liệu mẫu: 2 tài khoản demo
INSERT INTO tai_khoan (username, password, ten, tuoi, sodienthoai)
VALUES
('tk1','pass1','Người dùng 1',22,'0901000001'),
('tk2','pass1','Người dùng 2',25,'0901000002');

-- Liên kết Khach_hang mẫu (một người đã đăng ký gói, 1 chưa)
INSERT INTO Khach_hang (account_id, da_dang_ky_goi, goi_id, hlv_id, lich_tap, trang_thai_thanh_toan)
VALUES
(1, TRUE, 3, 1, 'SÁNG (8-11)', 'Đã thanh toán'),
(2, FALSE, NULL, NULL, NULL, 'Chưa thanh toán');

-- Thanh_toan mẫu
INSERT INTO Thanh_toan (account_id, ten, tuoi, ten_goi, tong_tien, trang_thai)
VALUES
(1,'Người dùng 1',22,'Gói 3 tháng - Tiết kiệm',800000.00,'Đã thanh toán'),
(2,'Người dùng 2',25,'','0.00','Chưa thanh toán');

