// app.js
// Frontend logic: đăng ký, đăng nhập, hiển thị gói, booking flow, profile edit.
// Thực hiện fetch tới các endpoint /api/... nếu có backend, nếu không sẽ fallback vào localStorage.

const API = {
  register: '/api/register',
  login: '/api/login',
  packages: '/api/packages',
  book: '/api/book',
  profile: '/api/profile',
  payments: '/api/payments'
};

// --- Utility: fallback 'DB' via localStorage ---
const LocalMock = {
  init(){
    if(!localStorage.getItem('mock_accounts')){
      // seed from SQL demo
      const accounts = [
        {account_id:1, username:'tk1', password:'pass1', ten:'Người dùng 1', tuoi:22, sodienthoai:'0901000001'},
        {account_id:2, username:'tk2', password:'pass1', ten:'Người dùng 2', tuoi:25, sodienthoai:'0901000002'}
      ];
      localStorage.setItem('mock_accounts', JSON.stringify(accounts));
    }
    if(!localStorage.getItem('mock_packages')){
      const pk = [
        {goi_id:1, so_bang:1, ten_goi:'Gói 1 tháng - Cơ bản', gia:300000, mo_ta:'Gói 1 tháng'},
        {goi_id:2, so_bang:2, ten_goi:'Gói 1 tháng - Nâng cao', gia:400000, mo_ta:'Kèm 2 buổi HLV'},
        {goi_id:3, so_bang:3, ten_goi:'Gói 3 tháng - Tiết kiệm', gia:800000, mo_ta:'Tiết kiệm'},
        {goi_id:4, so_bang:4, ten_goi:'Gói 6 tháng - Bạc', gia:1500000, mo_ta:''},
        {goi_id:5, so_bang:5, ten_goi:'Gói 12 tháng - Vàng', gia:2800000, mo_ta:''},
        {goi_id:6, so_bang:6, ten_goi:'Gói Sinh Viên 6 tháng', gia:1000000, mo_ta:''},
        {goi_id:7, so_bang:7, ten_goi:'Gói Tăng cơ 3 tháng', gia:900000, mo_ta:''},
        {goi_id:8, so_bang:8, ten_goi:'Gói Yoga 1 tháng', gia:350000, mo_ta:''}
      ];
      localStorage.setItem('mock_packages', JSON.stringify(pk));
    }
    if(!localStorage.getItem('mock_hlv')){
      const hlv = [
        {hlv_id:1, ten_hlv:'Nguyễn Văn A', anh_url:'', chuyen_mon:'Tăng cơ'},
        {hlv_id:2, ten_hlv:'Trần Thị B', anh_url:'', chuyen_mon:'Yoga'},
        {hlv_id:3, ten_hlv:'Lê Văn C', anh_url:'', chuyen_mon:'Cardio'}
      ];
      localStorage.setItem('mock_hlv', JSON.stringify(hlv));
    }
    if(!localStorage.getItem('mock_khach')){
      // Khach_hang entries link accounts (basic)
      const kh = [
        {kh_id:1, account_id:1, da_dang_ky_goi:true, goi_id:3, hlv_id:1, lich_tap:'SÁNG (8-11)', trang_thai_thanh_toan:'Đã thanh toán'},
        {kh_id:2, account_id:2, da_dang_ky_goi:false, goi_id:null, hlv_id:null, lich_tap:null, trang_thai_thanh_toan:'Chưa thanh toán'}
      ];
      localStorage.setItem('mock_khach', JSON.stringify(kh));
    }
    if(!localStorage.getItem('mock_payments')){
      const payments = [
        {tt_id:1, account_id:1, ten:'Người dùng 1', tuoi:22, ten_goi:'Gói 3 tháng - Tiết kiệm', tong_tien:800000, trang_thai:'Đã thanh toán'},
        {tt_id:2, account_id:2, ten:'Người dùng 2', tuoi:25, ten_goi:'', tong_tien:0, trang_thai:'Chưa thanh toán'}
      ];
      localStorage.setItem('mock_payments', JSON.stringify(payments));
    }
  },

  // accounts
  getAccounts(){ return JSON.parse(localStorage.getItem('mock_accounts')||'[]') },
  saveAccounts(list){ localStorage.setItem('mock_accounts', JSON.stringify(list)) },

  getPackages(){ return JSON.parse(localStorage.getItem('mock_packages')||'[]') },
  getHLV(){ return JSON.parse(localStorage.getItem('mock_hlv')||'[]') },
  getKhach(){ return JSON.parse(localStorage.getItem('mock_khach')||'[]') },
  saveKhach(list){ localStorage.setItem('mock_khach', JSON.stringify(list)) },
  getPayments(){ return JSON.parse(localStorage.getItem('mock_payments')||'[]') },
  savePayments(list){ localStorage.setItem('mock_payments', JSON.stringify(list)) }
};

// --- App state ---
let state = {
  currentUser: null, // {account_id, username, ten, ...}
  selectedPackage: null,
  selectedLich: null,
  selectedHlv: null
};

// --- Init ---
document.addEventListener('DOMContentLoaded', async () => {
  LocalMock.init();
  bindUI();
  enableModalUX();
  await loadPackages();
  renderUserState();
});

// --- UI bindings ---
function bindUI(){
  const elBtnRegister = document.getElementById('btn-register'); if(elBtnRegister) elBtnRegister.addEventListener('click', ()=> showModal('register'));
  const elBtnLogin = document.getElementById('btn-login'); if(elBtnLogin) elBtnLogin.addEventListener('click', ()=> showModal('login'));
  const elCloseLogin = document.getElementById('close-login'); if(elCloseLogin) elCloseLogin.addEventListener('click', (e)=> { e.preventDefault(); hideModal('login'); });
  const elCloseRegister = document.getElementById('close-register'); if(elCloseRegister) elCloseRegister.addEventListener('click', (e)=> { e.preventDefault(); hideModal('register'); });

  const elFormRegister = document.getElementById('form-register'); if(elFormRegister) elFormRegister.addEventListener('submit', onRegister);
  const elFormLogin = document.getElementById('form-login'); if(elFormLogin) elFormLogin.addEventListener('submit', onLogin);
  const elBtnLogout = document.getElementById('btn-logout'); if(elBtnLogout) elBtnLogout.addEventListener('click', logout);

  const elBtnPackages = document.getElementById('btn-packages'); if(elBtnPackages) elBtnPackages.addEventListener('click', ()=> scrollToPackages());

  // profile view buttons
  document.getElementById('btn-view-profile').addEventListener('click', ()=> showSection('profile-edit'));
  document.getElementById('btn-view-schedule').addEventListener('click', ()=> showSection('profile-schedule'));
  document.getElementById('btn-view-hlv').addEventListener('click', ()=> showSection('profile-hlv'));
  document.getElementById('btn-view-payment').addEventListener('click', ()=> showSection('payment-table'));
  document.getElementById('form-edit-profile').addEventListener('submit', onProfileEdit);

  // booking flow control
  document.getElementById('cancel-booking').addEventListener('click', cancelBooking);
  document.getElementById('to-step-2').addEventListener('click', ()=> {
    if(!state.selectedPackage){ alert('Chọn 1 gói trước!'); return; }
    document.getElementById('step-2').classList.remove('hidden');
  });
  document.getElementById('back-step-1').addEventListener('click', ()=> document.getElementById('step-2').classList.add('hidden'));
  document.getElementById('to-step-3').addEventListener('click', onToStep3);
  document.getElementById('back-step-2').addEventListener('click', ()=> {
    document.getElementById('step-3').classList.add('hidden');
    document.getElementById('step-2').classList.remove('hidden');
  });
  document.getElementById('confirm-pay').addEventListener('click', confirmPayment);
}

// --- Modal helpers ---
function showModal(which){
  const m = which==='login' ? document.getElementById('modal-login') : document.getElementById('modal-register');
  if(!m) return;
  m.classList.remove('hidden');
  // also ensure it's visible if inline style was set
  m.style.display = '';
}
function hideModal(which){
  const m = which==='login' ? document.getElementById('modal-login') : document.getElementById('modal-register');
  if(!m) return;
  m.classList.add('hidden');
  // defensive: also hide via style in case CSS differs
  m.style.display = 'none';
}

// Close modal when clicking outside inner or pressing Escape
function enableModalUX(){
  ['modal-login','modal-register'].forEach(id=>{
    const m = document.getElementById(id);
    if(!m) return;
    m.addEventListener('click', (e)=>{
      if(e.target === m){
        m.classList.add('hidden');
        m.style.display = 'none';
      }
    });
  });

  window.addEventListener('keydown', (e)=>{
    if(e.key === 'Escape'){
      const ml = document.getElementById('modal-login'); if(ml && !ml.classList.contains('hidden')) hideModal('login');
      const mr = document.getElementById('modal-register'); if(mr && !mr.classList.contains('hidden')) hideModal('register');
    }
  });
}

// --- Auth: register / login (uses real API if exists, else mock) ---
async function onRegister(e){
  e.preventDefault();
  const username = document.getElementById('reg-username').value.trim();
  const password = document.getElementById('reg-password').value.trim();
  const ten = document.getElementById('reg-name').value.trim();
  const tuoi = parseInt(document.getElementById('reg-age').value,10);
  const phone = document.getElementById('reg-phone').value.trim();

  // Try API
  try {
    const res = await fetch(API.register, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({username,password,ten,tuoi,phone})
    });
    if(res.ok){
      const data = await res.json();
      // auto login
      state.currentUser = data;
      console.log('API register succeeded, hiding register modal');
      hideModal('register');
      renderUserState();
      alert('Đăng ký thành công, đã đăng nhập!');
      return;
    } else {
      const txt = await res.text();
      console.warn('API register failed', txt);
      throw new Error('API register non-OK');
    }
  } catch(err){
    // fallback to local mock
    const accounts = LocalMock.getAccounts();
    if(accounts.find(a=>a.username===username)){
      alert('Tên tài khoản đã tồn tại! Vui lòng chọn tên khác.');
      return;
    }
    const newId = accounts.length? Math.max(...accounts.map(a=>a.account_id))+1:1;
    const newAcc = {account_id:newId, username, password, ten, tuoi, sodienthoai:phone};
    accounts.push(newAcc);
    LocalMock.saveAccounts(accounts);

    // create Khach_hang entry
    const kh = LocalMock.getKhach();
    const newKhId = kh.length? Math.max(...kh.map(k=>k.kh_id))+1:1;
    kh.push({kh_id:newKhId, account_id:newId, da_dang_ky_goi:false, goi_id:null, hlv_id:null, lich_tap:null, trang_thai_thanh_toan:'Chưa thanh toán'});
    LocalMock.saveKhach(kh);

    state.currentUser = newAcc;
    console.log('Mock register succeeded, hiding register modal');
    hideModal('register');
    renderUserState();
    alert('Đăng ký thành công (mock). Đã đăng nhập.');
  }
}

async function onLogin(e){
  e.preventDefault();
  const username = document.getElementById('login-username').value.trim();
  const password = document.getElementById('login-password').value.trim();

  try {
    const res = await fetch(API.login, {
      method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({username,password})
    });
    if(res.ok){
      const data = await res.json();
      state.currentUser = data;
      console.log('API login succeeded, hiding login modal');
      hideModal('login');
      renderUserState();
      return;
    } else {
      const txt = await res.text();
      console.warn('API login failed', txt);
      throw new Error('API login non-OK');
    }
  } catch(err){
    // fallback mock
    const accounts = LocalMock.getAccounts();
    const acc = accounts.find(a=>a.username===username && a.password===password);
    if(!acc){ alert('Tài khoản hoặc mật khẩu không đúng (mock).'); return; }
    state.currentUser = acc;
    console.log('Mock login succeeded, hiding login modal');
    hideModal('login');
    renderUserState();
  }
}

function logout(){
  state.currentUser = null;
  renderUserState();
  alert('Đã đăng xuất.');
}

// --- Render user state ---
function renderUserState(){
  const nick = document.getElementById('user-nickname');
  const userArea = document.getElementById('user-area');
  if(state.currentUser){
    userArea.classList.add('hidden');
    nick.classList.remove('hidden');
    document.getElementById('nick-name-text').innerText = state.currentUser.username;
    document.getElementById('profile-name').innerText = state.currentUser.ten || 'Thành viên';
    document.getElementById('profile-username').innerText = state.currentUser.username;
    // show profile default
    showSection('welcome');
    loadPersonalInfo();
  } else {
    userArea.classList.remove('hidden');
    nick.classList.add('hidden');
    document.getElementById('profile-name').innerText = 'Khách';
    document.getElementById('profile-username').innerText = '';
    showSection('welcome');
  }
}

// --- Load packages either from backend or mock ---
async function loadPackages(){
  try{
    const res = await fetch(API.packages);
    if(res.ok){
      const list = await res.json();
      renderPackages(list);
      return;
    }
  }catch(e){ /* ignore */ }

  // fallback local mock
  const list = LocalMock.getPackages();
  renderPackages(list);
}

function renderPackages(list){
  const grid = document.getElementById('packages-grid');
  grid.innerHTML = '';
  list.forEach(pkg=>{
    const card = document.createElement('div');
    card.className = 'package-card';
    card.innerHTML = `<h4>${pkg.ten_goi}</h4>
      <p>${pkg.mo_ta || ''}</p>
      <div><strong>${formatMoney(pkg.gia)}</strong></div>
      <div class="package-actions">
        <button class="btn btn-primary" onclick="startBooking(${pkg.goi_id})">Đặt gói</button>
        <button class="btn btn-outline" onclick="viewPackage(${pkg.goi_id})">Chi tiết</button>
      </div>`;
    grid.appendChild(card);
  });
}

// format money
function formatMoney(v){ return (Number(v)||0).toLocaleString('vi-VN',{style:'currency',currency:'VND'}); }

// start booking
function startBooking(goi_id){
  // find package from mock
  const pkg = LocalMock.getPackages().find(p=>p.goi_id===goi_id);
  if(!pkg) return alert('Gói không tồn tại');
  state.selectedPackage = pkg;
  document.getElementById('booking-flow').classList.remove('hidden');
  document.getElementById('selected-package').innerHTML = `<strong>${pkg.ten_goi}</strong> - ${formatMoney(pkg.gia)}`;
  document.getElementById('cart-details').innerText = `${pkg.ten_goi} - ${formatMoney(pkg.gia)}`;
  // reset steps
  document.getElementById('step-2').classList.add('hidden');
  document.getElementById('step-3').classList.add('hidden');
  // load hlv list
  renderHlvList();
}

function cancelBooking(){
  state.selectedPackage = null;
  state.selectedHlv = null;
  state.selectedLich = null;
  document.getElementById('booking-flow').classList.add('hidden');
  document.getElementById('cart-details').innerText = 'Chưa chọn gói.';
}

function renderHlvList(){
  const div = document.getElementById('hlv-list');
  div.innerHTML = '';
  const render = (list)=>{
    div.innerHTML = '';
    list.forEach(h=>{
      const item = document.createElement('div');
      item.className = 'hlv-item';
      item.innerHTML = `<div class="hlv-photo">${h.anh_url? `<img src="${h.anh_url}" style="max-width:100%;height:70px;object-fit:cover;border-radius:6px"/>` : 'Ảnh'}</div>
        <div>${h.ten_hlv}</div>
        <div style="font-size:12px">${h.chuyen_mon||''}</div>
        <div style="margin-top:6px"><button class="btn btn-outline" onclick="chooseHlv(${h.hlv_id})">Chọn</button></div>`;
      div.appendChild(item);
    });
  };
  // Try API first
  fetch('/api/hlv').then(r=> r.ok ? r.json(): Promise.reject()).then(render).catch(()=>{
    const list = LocalMock.getHLV();
    render(list);
  });
}

function chooseHlv(hlv_id){
  const hlv = LocalMock.getHLV().find(h=>h.hlv_id===hlv_id);
  if(!hlv) return;
  state.selectedHlv = hlv;
  alert('Đã chọn HLV: ' + hlv.ten_hlv);
}

// step 3
function onToStep3(){
  const sel = document.getElementById('select-lich').value;
  state.selectedLich = sel;
  if(!state.selectedHlv) return alert('Chọn HLV ở B2 trước');
  document.getElementById('step-2').classList.add('hidden');
  document.getElementById('step-3').classList.remove('hidden');
  document.getElementById('pay-summary').innerText = `${state.selectedPackage.ten_goi} — ${formatMoney(state.selectedPackage.gia)}\nLịch: ${state.selectedLich}\nHLV: ${state.selectedHlv.ten_hlv}`;
}

// confirm payment / create booking -> write to mock or call API
async function confirmPayment(){
  if(!state.currentUser) return alert('Bạn cần đăng nhập để đặt gói.');
  const payMethod = document.querySelector('input[name="pay-method"]:checked').value;
  // Attempt API
  try{
    const payload = {
      account_id: state.currentUser.account_id,
      goi_id: state.selectedPackage.goi_id,
      lich: state.selectedLich,
      hlv_id: state.selectedHlv.hlv_id,
      pay_method: payMethod
    };
    const res = await fetch(API.book, {
      method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)
    });
    if(res.ok){
      alert('Đặt gói thành công (API).');
      // refresh personal info
      loadPersonalInfo();
      cancelBooking();
      return;
    }
  }catch(e){ /* fallback */ }

  // fallback local mock: update Khach_hang and Thanh_toan
  const kh = LocalMock.getKhach();
  const idx = kh.findIndex(k=>k.account_id===state.currentUser.account_id);
  if(idx===-1){
    // create
    const newId = kh.length? Math.max(...kh.map(k=>k.kh_id))+1:1;
    kh.push({kh_id:newId, account_id:state.currentUser.account_id, da_dang_ky_goi:true, goi_id:state.selectedPackage.goi_id, hlv_id:state.selectedHlv.hlv_id, lich_tap:state.selectedLich, trang_thai_thanh_toan:'Đã thanh toán'});
  } else {
    kh[idx].da_dang_ky_goi = true;
    kh[idx].goi_id = state.selectedPackage.goi_id;
    kh[idx].hlv_id = state.selectedHlv.hlv_id;
    kh[idx].lich_tap = state.selectedLich;
    kh[idx].trang_thai_thanh_toan = 'Đã thanh toán';
  }
  LocalMock.saveKhach(kh);

  // payments
  const pays = LocalMock.getPayments();
  const newPayId = pays.length?Math.max(...pays.map(p=>p.tt_id))+1:1;
  pays.push({tt_id:newPayId, account_id:state.currentUser.account_id, ten:state.currentUser.ten, tuoi:state.currentUser.tuoi, ten_goi:state.selectedPackage.ten_goi, tong_tien:state.selectedPackage.gia, trang_thai:'Đã thanh toán'});
  LocalMock.savePayments(pays);

  alert('Đặt gói thành công (mock).');
  loadPersonalInfo();
  cancelBooking();
}

// --- Personal info load & profile edit ---
function loadPersonalInfo(){
  if(!state.currentUser) return;
  const account_id = state.currentUser.account_id;
  // Try API first
  (async ()=>{
    try{
      const res = await fetch(`/api/profile?account_id=${encodeURIComponent(account_id)}`);
      if(res.ok){
        const data = await res.json();
        const kh = data.kh;
        const pkg = data.pkg;
        const hlv = data.hlv;
        const payments = data.payments || [];
        if(kh && kh.da_dang_ky_goi){
          document.getElementById('schedule-info').innerHTML = `Gói: <strong>${pkg?pkg.ten_goi:'-'}</strong><br/>Lịch: ${kh.lich_tap || '-'}<br/>Trạng thái thanh toán: ${kh.trang_thai_thanh_toan}`;
          document.getElementById('my-hlv').innerHTML = hlv ? `<div><strong>${hlv.ten_hlv}</strong><div class="hlv-photo" style="height:100px">${hlv.anh_url?'<img src="'+hlv.anh_url+'" style="max-width:100%;height:100%;object-fit:cover">':'Ảnh'}</div></div>` : 'Chưa chọn HLV';
        } else {
          document.getElementById('schedule-info').innerText = 'Bạn chưa đăng ký gói.';
          document.getElementById('my-hlv').innerText = 'Chưa chọn HLV.';
        }
        const payDiv = document.getElementById('payment-list');
        payDiv.innerHTML = '';
        if(payments.length){
          payments.forEach(p=>{
            const el = document.createElement('div');
            el.style.padding='8px';
            el.style.borderBottom='1px solid #eee';
            el.innerHTML = `<div><strong>${p.ten_goi||'Chưa có gói'}</strong> - ${formatMoney(p.tong_tien)}</div>
              <div>Trạng thái: <span style="color:${p.trang_thai==='Đã thanh toán'?'green':'red'}">${p.trang_thai}</span></div>`;
            payDiv.appendChild(el);
          });
        } else {
          payDiv.innerText = 'Không có bản ghi thanh toán.';
        }
        // prefill edit form
        document.getElementById('edit-name').value = state.currentUser.ten || '';
        document.getElementById('edit-age').value = state.currentUser.tuoi || '';
        return;
      }
    }catch(e){ /* fallback */ }

    // Fallback local mock
    const kh = LocalMock.getKhach().find(k=>k.account_id===account_id);
    const payments = LocalMock.getPayments().filter(p=>p.account_id===account_id);
    if(kh && kh.da_dang_ky_goi){
      const pkg = LocalMock.getPackages().find(p=>p.goi_id===kh.goi_id);
      const hlv = LocalMock.getHLV().find(h=>h.hlv_id===kh.hlv_id);
      document.getElementById('schedule-info').innerHTML = `Gói: <strong>${pkg?pkg.ten_goi:'-'}</strong><br/>Lịch: ${kh.lich_tap || '-'}<br/>Trạng thái thanh toán: ${kh.trang_thai_thanh_toan}`;
      document.getElementById('my-hlv').innerHTML = hlv ? `<div><strong>${hlv.ten_hlv}</strong><div class="hlv-photo" style="height:100px">${hlv.anh_url?'<img src="'+hlv.anh_url+'" style="max-width:100%;height:100%;object-fit:cover">':'Ảnh'}</div></div>` : 'Chưa chọn HLV';
    } else {
      document.getElementById('schedule-info').innerText = 'Bạn chưa đăng ký gói.';
      document.getElementById('my-hlv').innerText = 'Chưa chọn HLV.';
    }
    const payDiv = document.getElementById('payment-list');
    payDiv.innerHTML = '';
    if(payments.length){
      payments.forEach(p=>{
        const el = document.createElement('div');
        el.style.padding='8px';
        el.style.borderBottom='1px solid #eee';
        el.innerHTML = `<div><strong>${p.ten_goi||'Chưa có gói'}</strong> - ${formatMoney(p.tong_tien)}</div>
          <div>Trạng thái: <span style="color:${p.trang_thai==='Đã thanh toán'?'green':'red'}">${p.trang_thai}</span></div>`;
        payDiv.appendChild(el);
      });
    } else {
      payDiv.innerText = 'Không có bản ghi thanh toán.';
    }
    document.getElementById('edit-name').value = state.currentUser.ten || '';
    document.getElementById('edit-age').value = state.currentUser.tuoi || '';
  })();
}

function onProfileEdit(e){
  e.preventDefault();
  if(!state.currentUser) return alert('Đăng nhập để chỉnh sửa.');
  const newName = document.getElementById('edit-name').value.trim();
  const newAge = parseInt(document.getElementById('edit-age').value,10);
  const newPassword = document.getElementById('edit-password').value.trim();

  // try API update first
  (async ()=>{
    try{
      const payload = { account_id: state.currentUser.account_id };
      if(newName) payload.ten = newName;
      if(newAge) payload.tuoi = newAge;
      if(newPassword) payload.password = newPassword;
      const res = await fetch('/api/profile', { method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
      if(res.ok){
        const updated = await res.json();
        state.currentUser = { ...state.currentUser, ...updated };
        renderUserState();
        alert('Cập nhật thông tin thành công.');
        return;
      }
    }catch(err){ /* fallback */ }

    // fallback mock update
    const accounts = LocalMock.getAccounts();
    const idx = accounts.findIndex(a=>a.account_id===state.currentUser.account_id);
    if(idx!==-1){
      accounts[idx].ten = newName || accounts[idx].ten;
      accounts[idx].tuoi = newAge || accounts[idx].tuoi;
      if(newPassword) accounts[idx].password = newPassword;
      LocalMock.saveAccounts(accounts);
      state.currentUser = accounts[idx];
      renderUserState();
      alert('Cập nhật thông tin thành công (mock).');
      return;
    }
  })();
}

// --- helpers view sections ---
function showSection(id){
  const sections = ['welcome','profile-edit','profile-schedule','profile-hlv','payment-table'];
  sections.forEach(s => document.getElementById(s).classList.add('hidden'));
  document.getElementById(id).classList.remove('hidden');
}

function viewPackage(goi_id){
  const pkg = LocalMock.getPackages().find(p=>p.goi_id===goi_id);
  alert(`Chi tiết: ${pkg.ten_goi}\nGiá: ${formatMoney(pkg.gia)}\nMô tả: ${pkg.mo_ta}`);
}

function scrollToPackages(){
  document.querySelector('.center-col').scrollIntoView({behavior:'smooth'});
}
